GMP
    - Location des vehicules : camions | poids legers
    - Gestion des contrats BTP
    - Gestion de l'immobilier


LES TACHES QUOITIDIENNES
    CONTINUER A BOSSER AVEC LE PROJET GMP SARL CONFORMEMENT AUX POINTS DISCUTES AVEC TOURE
        - GESTION DE LA CONNEXION
        - GESTION DES PARTENAIRES
        - GESTION DES CONTRATS/FACTURES
            * CATEGORIES
            * DETAILS
            * AFFECTATIONS EMPLOYEE
        ------------------------
        GESTION DES PAIEMENTS DE SALAIRE
        FACTURE CONTRACT | PDF ALL CONTRACTS
        REGLEMENT FACTURE CONTRACT | PDF


wget --secure-protocol=TLSv1_3 --mirror --convert-links --page-requisites --no-parent https://demo.dashboardpack.com/admindek-html


