LES TACHES DE LA JOURNEE
    - ECRIRE AU SUPPORT FAIT
    - CHARGE LE PROJET PAWCOINS ET REMPLIR LE FORM fait
    - VOIR D'AUTRES POSSIBILITES EMAILS AU 9000? En attente de la prod de Amazon SES


    - CONTINUER LES RECHERCHES SUR POLYGON, TELECHARGER LE FORM D'APPLICATION ---
    - PHASE II AGRISTOCK
        Hub2 : Ecrit, Intouc integré pour le paiement En cours
        Rechercher sur l'analyse des données, que des éléments pertinents fait
        Refaire le tableau pour les phases II et III pour chacun des éléments
        Politique de confidentialité favorable à l'entreprise, nous protégeant fait
        UX avec un LOW Alphabet fait

    - CONTINUER A BOSSER SUR MAFAMO
        - GESTION DES INDISPONIBILITES fait
        - GESTION DES CAISSES fait
        - REGLEMENT PAIEMENT
        - REGLEMENT FACTURE DEVIS
        - INTERFACE RESERVATION
            - GESTION DES TYPES : STUDIO, APARTEMENT, fait
            - GESTION DES ROOMS fait
                type_id, address, price_gnf, price_euro, price_dollar
            - GESTION DES IMAGES fait
                url, room_id
            - GESTION DES RATES
                note, room_id
            - GESTION DES RESERVATION
                - type : RESERVATION | LOCATION | ACHAT, begin, end, amount, customername, customerphone



