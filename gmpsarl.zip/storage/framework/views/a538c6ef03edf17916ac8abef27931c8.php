<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="page-titles dark:bg-[#242424] flex items-center justify-between relative border-b border-[#E6E6E6] dark:border-[#444444] flex-wrap z-[1] py-[0.6rem] sm:px-[1.95rem] px-[1.55rem] bg-white">
        <ol class="text-[13px] flex items-center flex-wrap bg-transparent">
            <li>
                <a href="<?php echo e(route('employees.index')); ?>" class="text-[#828690] dark:text-white text-[13px]">
                    <svg class="mb-[3px] mr-1 inline-block" width="17" height="17" viewBox="0 0 17 17" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M2.125 6.375L8.5 1.41667L14.875 6.375V14.1667C14.875 14.5424 14.7257 14.9027 14.4601 15.1684C14.1944 15.4341 13.8341 15.5833 13.4583 15.5833H3.54167C3.16594 15.5833 2.80561 15.4341 2.53993 15.1684C2.27426 14.9027 2.125 14.5424 2.125 14.1667V6.375Z" stroke="#2C2C2C" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M6.375 15.5833V8.5H10.625V15.5833" stroke="#2C2C2C" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                    <?php echo app('translator')->get('locale.partner', ['suffix'=>'s']); ?> 
                </a>
            </li>
            <li class="pl-2 before:content-['/'] before:font-[simple-line-icons] before:font-black before:text-xl before:leading-4 before:pr-2 before:float-left before:text-primary text-primary font-medium"><a><?php echo app('translator')->get('locale.edit'); ?></a></li>
        </ol>
    </div>

    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body relative p-[1.875rem]">
                        <form action="<?php echo e(route('employees.update', $employee->id)); ?>" method="post">
                            <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                            <div class="row">	
                                <div class="xl:w-full mb-4">
                                    <label for="name" class="form-label"><?php echo app('translator')->get('locale.name'); ?> <span class="text-danger">*</span></label>
                                    <input type="text" name="name" value="<?php echo e($employee->name); ?>" class="form-control relative text-[13px] text-body-color h-[2.813rem] border border-b-color block rounded-md py-1.5 px-3 duration-500 focus:border-primary dark:hover:border-b-color outline-none w-full" id="name" placeholder="<?php echo app('translator')->get('locale.name'); ?>" required>
                                </div>	
                                <div class="xl:w-1/2 mb-4">
                                    <label for="phone" class="form-label"><?php echo app('translator')->get('locale.phone'); ?> <span class="text-danger">*</span></label>
                                    <input type="tel" name="phone" value="<?php echo e($employee->phone); ?>" class="form-control relative text-[13px] text-body-color h-[2.813rem] border border-b-color block rounded-md py-1.5 px-3 duration-500 focus:border-primary dark:hover:border-b-color outline-none w-full" id="phone" placeholder="<?php echo app('translator')->get('locale.phone'); ?>" required>
                                </div>
                                <div class="xl:w-1/2 mb-4">
                                    <label for="email" class="form-label"><?php echo app('translator')->get('locale.email'); ?></label>
                                    <input type="email" name="email" value="<?php echo e($employee->email); ?>" class="form-control relative text-[13px] text-body-color h-[2.813rem] border border-b-color block rounded-md py-1.5 px-3 duration-500 focus:border-primary dark:hover:border-b-color outline-none w-full" id="email" placeholder="<?php echo app('translator')->get('locale.email'); ?>">
                                </div>
                                <div class="xl:w-1/2 mb-4">
                                    <label for="address" class="form-label"><?php echo app('translator')->get('locale.address'); ?> <span class="text-danger">*</span></label>
                                    <input type="text" name="address" value="<?php echo e($employee->address); ?>" class="form-control relative text-[13px] text-body-color h-[2.813rem] border border-b-color block rounded-md py-1.5 px-3 duration-500 focus:border-primary dark:hover:border-b-color outline-none w-full" id="address" placeholder="<?php echo app('translator')->get('locale.address'); ?>" required>
                                </div>
                                <div class="xl:w-1/2 mb-4">
                                    <label class="form-label"><?php echo app('translator')->get('locale.gender'); ?><span class="text-danger">*</span></label>
                                    <select name="gender" class="nice-select style-1 py-1.5 px-3 bg-transparent text-[13px] font-normal outline-none relative focus:ring-0 border border-b-color text-[#a5a5a5] h-[2.813rem] leading-[1.813rem]" required>
                                        <option data-display="<?php echo app('translator')->get('locale.select'); ?>"><?php echo app('translator')->get('locale.select'); ?></option>
                                        <?php $__currentLoopData = ['Mr','Mme']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option <?php echo e($employee->gender == $item ? 'selected' : ''); ?>><?php echo e($item); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="xl:w-1/2 mb-4">
                                    <label class="form-label"><?php echo app('translator')->get('locale.diploma'); ?><span class="text-danger">*</span></label>
                                    <select name="diploma" class="nice-select style-1 py-1.5 px-3 bg-transparent text-[13px] font-normal outline-none relative focus:ring-0 border border-b-color text-[#a5a5a5] h-[2.813rem] leading-[1.813rem]" required>
                                        <option data-display="<?php echo app('translator')->get('locale.select'); ?>"><?php echo app('translator')->get('locale.select'); ?></option>
                                        <?php $__currentLoopData = ['CEP','BTS','BEPC','BACCALAUREAT','LICENCE','MASTER','PhD', 'AUTRE']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option <?php echo e($employee->diploma == $item ? 'selected' : ''); ?>><?php echo e($item); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="xl:w-1/2 mb-4">
                                    <label class="form-label"><?php echo app('translator')->get('locale.family'); ?><span class="text-danger">*</span></label>
                                    <select name="family" class="nice-select style-1 py-1.5 px-3 bg-transparent text-[13px] font-normal outline-none relative focus:ring-0 border border-b-color text-[#a5a5a5] h-[2.813rem] leading-[1.813rem]" required>
                                        <option data-display="<?php echo app('translator')->get('locale.select'); ?>"><?php echo app('translator')->get('locale.select'); ?></option>
                                        <?php $__currentLoopData = ['CELIBATAIRE','MARIE(E)','DIVORCE(E)']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option <?php echo e($employee->family == $item ? 'selected' : ''); ?>><?php echo e($item); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="xl:w-1/2 mb-4">
                                    <label class="form-label"><?php echo app('translator')->get('locale.contracttype'); ?><span class="text-danger">*</span></label>
                                    <select name="contracttype" class="nice-select style-1 py-1.5 px-3 bg-transparent text-[13px] font-normal outline-none relative focus:ring-0 border border-b-color text-[#a5a5a5] h-[2.813rem] leading-[1.813rem]" required>
                                        <option data-display="<?php echo app('translator')->get('locale.select'); ?>"><?php echo app('translator')->get('locale.select'); ?></option>
                                        <?php $__currentLoopData = ['CDI','CDD','STAGE','AUTRE']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option <?php echo e($employee->contracttype == $item ? 'selected' : ''); ?>><?php echo e($item); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="xl:w-1/2 mb-4">
                                    <label for="position" class="form-label"><?php echo app('translator')->get('locale.position'); ?> <span class="text-danger">*</span></label>
                                    <input type="text" name="position" value="<?php echo e($employee->position); ?>" class="form-control relative text-[13px] text-body-color h-[2.813rem] border border-b-color block rounded-md py-1.5 px-3 duration-500 focus:border-primary dark:hover:border-b-color outline-none w-full" id="position" placeholder="<?php echo app('translator')->get('locale.position'); ?>" required>
                                </div>
                                <div class="xl:w-1/2 mb-4">
                                    <label for="contractbegin" class="form-label"><?php echo app('translator')->get('locale.contractbegin'); ?> <span class="text-danger">*</span></label>
                                    <input type="date" name="contractbegin" value="<?php echo e($employee->contractbegin); ?>" class="form-control relative text-[13px] text-body-color h-[2.813rem] border border-b-color block rounded-md py-1.5 px-3 duration-500 focus:border-primary dark:hover:border-b-color outline-none w-full" id="contractbegin" placeholder="<?php echo app('translator')->get('locale.contractbegin'); ?>" required>
                                </div>
                                <div class="xl:w-1/2 mb-4">
                                    <label for="contractend" class="form-label"><?php echo app('translator')->get('locale.contractend'); ?> <span class="text-danger">*</span></label>
                                    <input type="date" name="contractend" value="<?php echo e($employee->contractend); ?>" class="form-control relative text-[13px] text-body-color h-[2.813rem] border border-b-color block rounded-md py-1.5 px-3 duration-500 focus:border-primary dark:hover:border-b-color outline-none w-full" id="contractend" placeholder="<?php echo app('translator')->get('locale.contractend'); ?>" required>
                                </div>
                                <div class="xl:w-1/2 mb-4">
                                    <label for="brut" class="form-label"><?php echo app('translator')->get('locale.brut'); ?> <span class="text-danger">*</span></label>
                                    <input type="number" name="brut" value="<?php echo e($employee->brut); ?>" class="form-control relative text-[13px] text-body-color h-[2.813rem] border border-b-color block rounded-md py-1.5 px-3 duration-500 focus:border-primary dark:hover:border-b-color outline-none w-full" id="brut" placeholder="<?php echo app('translator')->get('locale.brut'); ?>" min="100000" required>
                                </div>
                                <div class="xl:w-1/2 mb-4">
                                    <label for="prime" class="form-label"><?php echo app('translator')->get('locale.prime'); ?> <span class="text-danger">*</span></label>
                                    <input type="number" name="prime" value="<?php echo e($employee->prime); ?>" class="form-control relative text-[13px] text-body-color h-[2.813rem] border border-b-color block rounded-md py-1.5 px-3 duration-500 focus:border-primary dark:hover:border-b-color outline-none w-full" id="prime" value="0" min="0" placeholder="<?php echo app('translator')->get('locale.prime'); ?>" required>
                                </div>	
                                <div class="xl:w-1/2 mb-4">
                                    <label for="warrantyperson" class="form-label"><?php echo app('translator')->get('locale.warrantyperson'); ?> <span class="text-danger">*</span></label>
                                    <input type="text" name="warrantyperson" value="<?php echo e($employee->warrantyperson); ?>" class="form-control relative text-[13px] text-body-color h-[2.813rem] border border-b-color block rounded-md py-1.5 px-3 duration-500 focus:border-primary dark:hover:border-b-color outline-none w-full" id="warrantyperson" placeholder="<?php echo app('translator')->get('locale.warrantyperson'); ?>" required>
                                </div>
                                <div class="xl:w-1/2 mb-4">
                                    <label for="warrantyphone" class="form-label"><?php echo app('translator')->get('locale.warrantyphone'); ?> <span class="text-danger">*</span></label>
                                    <input type="text" name="warrantyphone" value="<?php echo e($employee->warrantyphone); ?>" class="form-control relative text-[13px] text-body-color h-[2.813rem] border border-b-color block rounded-md py-1.5 px-3 duration-500 focus:border-primary dark:hover:border-b-color outline-none w-full" id="warrantyphone" placeholder="<?php echo app('translator')->get('locale.warrantyphone'); ?>" required>
                                </div>
                                <div class="xl:w-1/2 mb-4">
                                    <label for="rib" class="form-label"><?php echo app('translator')->get('locale.rib'); ?></label>
                                    <input type="text" name="rib" value="<?php echo e($employee->rib); ?>" class="form-control relative text-[13px] text-body-color h-[2.813rem] border border-b-color block rounded-md py-1.5 px-3 duration-500 focus:border-primary dark:hover:border-b-color outline-none w-full" id="rib" placeholder="<?php echo app('translator')->get('locale.rib'); ?>">
                                </div>
                                <div class="xl:w-1/2 mb-4">
                                    <label for="bank" class="form-label"><?php echo app('translator')->get('locale.bank'); ?></label>
                                    <input type="text" name="bank" value="<?php echo e($employee->bank); ?>" class="form-control relative text-[13px] text-body-color h-[2.813rem] border border-b-color block rounded-md py-1.5 px-3 duration-500 focus:border-primary dark:hover:border-b-color outline-none w-full" id="bank" placeholder="<?php echo app('translator')->get('locale.bank'); ?>">
                                </div>	
                                <div class="w-full">
                                    <button class="btn btn-success xl:py-[0.719rem] py-2.5 xl:px-[1.563rem] px-4 duration-300 xl:text-[15px] text-[13px] font-medium rounded text-white bg-primary leading-5 inline-block border border-primary hover:bg-hover-primary offcanvas-close"><?php echo app('translator')->get('locale.submit'); ?></button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php $__env->startPush('scripts'); ?>
	<script src="<?php echo e(asset('vendor/niceselect/js/jquery.nice-select.min.js')); ?>"></script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>

<?php /**PATH C:\laragon\www\gmpsarl.com\resources\views/admin/employees/edit.blade.php ENDPATH**/ ?>