


<div class="az-iconbar">
    <a class="az-iconbar-logo" href="<?php echo e(route('dashboard')); ?>">
        <img src="<?php echo e(asset('images/gmp.png')); ?>" alt="LOGO" height="30">
    </a>
    <nav class="nav">
        <a class="nav-link <?php echo e(Route::is('dashboard') ? 'active' : ''); ?>" href="<?php echo e(route('dashboard')); ?>">
            <i class="typcn typcn-device-laptop"></i>
        </a>
        <a class="nav-link" href="#asideContracts">
            <i class="typcn typcn-calendar-outline"></i>
        </a>
        <a class="nav-link" href="#asideUIElements">
            <i class="typcn typcn-book"></i>
        </a>
        <a class="nav-link" href="#asideForms">
            <i class="typcn typcn-folder-add"></i>
        </a>
        <a class="nav-link" href="#asideCharts">
            <i class="typcn typcn-chart-line-outline"></i>
        </a>
        <a class="nav-link" href="#asideMaps">
            <i class="typcn typcn-map"></i>
        </a>
        <a class="nav-link" href="#asideTables">
            <i class="typcn typcn-th-large-outline"></i>
        </a>
        <a class="nav-link" href="#asideUtil">
            <i class="typcn typcn-archive"></i>
        </a>
    </nav>
    <div class="az-iconbar-bottom">
        <a class="az-iconbar-help" href="">
            <i class="far fa-question-circle"></i>
        </a>
        <a class="az-img-user online" href="">
            <img alt="" src="https://via.placeholder.com/500"/>
        </a>
    </div>
</div>
 
<div class="az-iconbar-aside">
    <div class="az-iconbar-header">
        <a class="az-logo" href="<?php echo e(route('dashboard')); ?>">
            <img src="<?php echo e(asset('images/gmp.png')); ?>" alt="LOGO" height="40">
        </a>
        <a class="az-iconbar-toggle-menu" href="">
            <i class="icon ion-md-arrow-back"></i>
            <i class="icon ion-md-close"></i>
        </a>
    </div>
    <div class="az-iconbar-body">
        <div class="az-iconbar-pane" id="asideContracts">
            <h6 class="az-iconbar-title"><?php echo app('translator')->get('locale.contract', ['suffix'=>'']); ?></h6>
            <small class="az-iconbar-text"><?php echo app('translator')->get('locale.contract_management'); ?></small>
            <ul class="nav">
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('partners.index')); ?>"><?php echo app('translator')->get('locale.partner', ['suffix'=>'s']); ?></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('contracts.index')); ?>"><?php echo app('translator')->get('locale.contract', ['suffix'=>'s']); ?></a>
                </li>
            </ul>
        </div>
        <div class="az-iconbar-pane" id="asideUIElements">
        <h6 class="az-iconbar-title">
        UI Elements
        </h6>
        <small class="az-iconbar-text">
        Reusable elements built to provide buttons, dropdowns, input, navigation, alerts, and much more
        </small>
        <ul class="nav">
        <li class="nav-item">
            <a class="nav-link" href="elem-accordion.html">
            Accordion
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="elem-alerts.html">
            Alerts
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="elem-avatar.html">
            Avatar
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="elem-badge.html">
            Badge
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="elem-breadcrumbs.html">
            Breadcrumbs
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="elem-buttons.html">
            Buttons
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="elem-cards.html">
            Cards
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="elem-carousel.html">
            Carousel
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="elem-collapse.html">
            Collapse
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="elem-dropdown.html">
            Dropdown
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="elem-icons.html">
            Icons
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="elem-images.html">
            Images
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="elem-list-group.html">
            List Group
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="elem-media-object.html">
            Media Object
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="elem-modals.html">
            Modals
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="elem-navigation.html">
            Navigation
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="elem-pagination.html">
            Pagination
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="elem-popover.html">
            Popover
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="elem-progress.html">
            Progress
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="elem-spinners.html">
            Spinners
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="elem-toast.html">
            Toast
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="elem-tooltip.html">
            Tooltip
            </a>
        </li>
        </ul>
        </div>
        <div class="az-iconbar-pane" id="asideForms">
        <h6 class="az-iconbar-title">
        Forms
        </h6>
        <small class="az-iconbar-text">
        Forms are used to collect user information with different element types of inputs.
        </small>
        <ul class="nav">
        <li class="nav-item">
            <a class="nav-link" href="form-elements.html">
            Form Elements
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="form-layouts.html">
            Form Layouts
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="form-validation.html">
            Form Validation
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="form-wizards.html">
            Form Wizards
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="form-editor.html">
            WYSIWYG Editor
            </a>
        </li>
        </ul>
        </div>
        <div class="az-iconbar-pane" id="asideCharts">
        <h6 class="az-iconbar-title">
        Charts
        </h6>
        <small class="az-iconbar-text">
        A sheet of information in the form of a table, graph, or diagram.
        </small>
        <ul class="nav">
        <li class="nav-item">
            <a class="nav-link" href="chart-morris.html">
            Morris Charts
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="chart-flot.html">
            Flot Charts
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="chart-chartjs.html">
            ChartJS
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="chart-sparkline.html">
            Sparkline
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="chart-peity.html">
            Peity
            </a>
        </li>
        </ul>
        </div>
        <div class="az-iconbar-pane" id="asideMaps">
        <h6 class="az-iconbar-title">
        Maps
        </h6>
        <small class="az-iconbar-text">
        An interactive display of geographic information that you can use for location and more.
        </small>
        <ul class="nav">
        <li class="nav-item">
            <a class="nav-link" href="map-google.html">
            Google Maps
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="map-leaflet.html">
            Leaflet
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="map-vector.html">
            Vector Maps
            </a>
        </li>
        </ul>
        </div>
        <div class="az-iconbar-pane" id="asideTables">
        <h6 class="az-iconbar-title">
        Tables
        </h6>
        <small class="az-iconbar-text">
        A collection basic to advanced table design that you can use to your data.
        </small>
        <ul class="nav">
        <li class="nav-item">
            <a class="nav-link" href="table-basic.html">
            Basic Tables
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="table-data.html">
            Data Tables
            </a>
        </li>
        </ul>
        </div>
        <div class="az-iconbar-pane" id="asideUtil">
        <h6 class="az-iconbar-title">
        Utilities
        </h6>
        <small class="az-iconbar-text">
        A collection of helper classes as additional styles to an element.
        </small>
        <ul class="nav">
        <li class="nav-item">
            <a class="nav-link" href="util-background.html">
            Background
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="util-border.html">
            Border
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="util-display.html">
            Display
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="util-flex.html">
            Flex
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="util-height.html">
            Height
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="util-margin.html">
            Margin
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="util-padding.html">
            Padding
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="util-position.html">
            Position
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="util-typography.html">
            Typography
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="util-width.html">
            Width
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="util-extras.html">
            Extras
            </a>
        </li>
        </ul>
        </div>
    </div>
</div><?php /**PATH C:\laragon\www\gmpsarl.com\resources\views/components/app-sidebar.blade.php ENDPATH**/ ?>