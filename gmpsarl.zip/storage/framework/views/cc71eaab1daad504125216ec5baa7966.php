<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startPush('links'); ?>
    <link href="<?php echo e(asset('vendor/datatables/css/jquery.dataTables.min.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(asset('vendor/niceselect/css/nice-select.css')); ?>" rel="stylesheet">
    <?php $__env->stopPush(); ?>

    <div class="page-titles dark:bg-[#242424] flex items-center justify-between relative border-b border-[#E6E6E6] dark:border-[#444444] flex-wrap z-[1] py-[0.6rem] sm:px-[1.95rem] px-[1.55rem] bg-white">
        <ol class="text-[13px] flex items-center flex-wrap bg-transparent">
            <li><a href="<?php echo e(route('rooms.index')); ?>" class="text-[#828690] dark:text-white text-[13px]"><?php echo app('translator')->get('locale.room', ['suffix'=>'s']); ?></a></li>
            <li class="pl-2 before:content-['/'] before:font-[simple-line-icons] before:font-black before:text-xl before:leading-4 before:pr-2 before:float-left before:text-primary text-primary font-medium"><a><?php echo e($room->name); ?></a></li>
        </ol>
    </div>

    <div class="container-fluid">
        <div class="row">
            <div class="w-full">
                <div class="card">
                    <div class="card-header flex justify-between items-center sm:p-5 sm:pt-6 p-4 pt-5 max-sm:pb-5 relative z-[2]">
                        <h4 class="heading blog-title relative"><?php echo e($room->type->type." ".$room->name); ?></h4>
                        <a href="javascript:void(0)" class="btn hover:bg-hover-primary duration-500 py-[5px] px-3 text-[13px] font-normal rounded text-white bg-primary leading-[18px] inline-block border border-primary offcanvas-toggle" data-dz-offcanvas="new-image">+ <?php echo app('translator')->get('locale.add'); ?> <?php echo app('translator')->get('locale.image', ['suffix'=>'']); ?></a>
                    </div>
                    <div class="card-body sm:p-5 p-4">
                        <div class="row">
                            <div class="w-1/2">
                                <div class="blog-img relative">
                                    <img src="<?php echo e(asset($room->front)); ?>" alt="PHOTO I" class="sm:h-[400px] h-[300px] w-full object-cover rounded-md">
                                    <div class="absolute py-5 px-[15px] bottom-0">
                                        <h2 class="xl:text-3xl text-xl text-white leading-[1.1] font-semibold mb-2">PHOTO I</h2>
                                        <img src="<?php echo e(asset('images/profile.png')); ?>" class="h-[1.275rem] w-[1.275rem] relative inline-block object-cover rounded-full mr-2 small-post" alt="">
                                        <span class="text-white text-sm"><?php echo e($room->address); ?></span>
                                    </div>
                                </div>
                            </div>
                            <div class="w-1/2">
                                <div class="blog-img relative">
                                    <img src="<?php echo e(asset($room->back)); ?>" alt="PHOTO II" class="sm:h-[400px] h-[300px] w-full object-cover rounded-md">
                                    <div class="absolute py-5 px-[15px] bottom-0">
                                        <h2 class="xl:text-3xl text-xl text-white leading-[1.1] font-semibold mb-2">PHOTO II</h2>
                                        <img src="<?php echo e(asset('images/profile.png')); ?>" class="h-[1.275rem] w-[1.275rem] relative inline-block object-cover rounded-full mr-2 small-post" alt="">
                                        <span class="text-white text-sm"><?php echo e($room->address); ?></span>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <?php $__currentLoopData = $room->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="xl:w-1/2 w-full">
                                <div class="flex mt-[25px] max-sm:flex-wrap">
                                    <img src="<?php echo e(asset($item->link)); ?>" alt="PHOTO" class="sm:w-[160px] w-full mr-[18px] sm:h-[130px] h-[200px] object-cover rounded-md">
                                    <div class="post-1">
                                        <div class="max-xl:mt-[15px]">
                                            <span class="text-xs py-[0.3125rem] px-2 leading-[0.6875rem] font-medium text-white text-center whitespace-nowrap rounded inline-block bg-info dz-modal-btn" data-dz-modal="edit-image<?php echo e($item->id); ?>"><i class="fa fa-edit"></i> <?php echo app('translator')->get('locale.edit'); ?></span>
                                            <h4 class="text-[13px] mt-1.5 mb-2"><?php echo e($item->description ?? __('locale.no_description')); ?>.</h4>
                                            <div>
                                                <img src="<?php echo e(asset('images/profile.png')); ?>" class="h-[1.275rem] w-[1.275rem] relative inline-block object-cover rounded-full mr-2 small-post" alt="PROFILE">
                                                <span class="text-xs text-body-color"><b class="text-primary"><?php echo app('translator')->get('locale.created_at'); ?></b> <?php echo e(date('d/m/Y H:i:s', strtotime($item->created_at))); ?></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php if (isset($component)) { $__componentOriginal22c009f1bb53f0c1b08bd2478374eea6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal22c009f1bb53f0c1b08bd2478374eea6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.edit-image','data' => ['room' => $room,'image' => $item]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('edit-image'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['room' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($room),'image' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($item)]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal22c009f1bb53f0c1b08bd2478374eea6)): ?>
<?php $attributes = $__attributesOriginal22c009f1bb53f0c1b08bd2478374eea6; ?>
<?php unset($__attributesOriginal22c009f1bb53f0c1b08bd2478374eea6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal22c009f1bb53f0c1b08bd2478374eea6)): ?>
<?php $component = $__componentOriginal22c009f1bb53f0c1b08bd2478374eea6; ?>
<?php unset($__componentOriginal22c009f1bb53f0c1b08bd2478374eea6); ?>
<?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php if (isset($component)) { $__componentOriginala04fbe871fb777f841ff141b6bc4f6e3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala04fbe871fb777f841ff141b6bc4f6e3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.add-image','data' => ['room' => $room]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('add-image'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['room' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($room)]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala04fbe871fb777f841ff141b6bc4f6e3)): ?>
<?php $attributes = $__attributesOriginala04fbe871fb777f841ff141b6bc4f6e3; ?>
<?php unset($__attributesOriginala04fbe871fb777f841ff141b6bc4f6e3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala04fbe871fb777f841ff141b6bc4f6e3)): ?>
<?php $component = $__componentOriginala04fbe871fb777f841ff141b6bc4f6e3; ?>
<?php unset($__componentOriginala04fbe871fb777f841ff141b6bc4f6e3); ?>
<?php endif; ?>
    <?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('vendor/datatables/js/jquery.dataTables.min.js')); ?>"></script>
	<script src="<?php echo e(asset('vendor/datatables/js/dataTables.buttons.min.js')); ?>"></script>
	<script src="<?php echo e(asset('vendor/datatables/js/buttons.html5.min.js')); ?>"></script>
	<script src="<?php echo e(asset('vendor/datatables/js/jszip.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/plugins-init/datatables.init.min.js')); ?>"></script>
	<script src="<?php echo e(asset('vendor/niceselect/js/jquery.nice-select.min.js')); ?>"></script> 
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>

<?php /**PATH C:\laragon\www\gmpsarl.com\resources\views/admin/rooms/show.blade.php ENDPATH**/ ?>