<script src="<?php echo e(asset('lib/datatables.net-dt/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('lib/datatables.net-dt/js/dataTables.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('lib/datatables.net-responsive-dt/js/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(asset('lib/datatables.net-responsive-dt/js/responsive.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('lib/select2/js/select2.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/azia.js')); ?>"></script>
<script>
    $(function() {
        $('.select2').select2({
            placeholder: 'Choose one',
            searchInputPlaceholder: "<?php echo app('translator')->get('locale.search'); ?>..."
        });

        $('.datatable').DataTable({
            responsive: true,
            language: {
                searchPlaceholder: "<?php echo app('translator')->get('locale.search'); ?>...",
                search: '',
                lengthMenu: '_MENU_',
            }
        });
        
        // Select2
        $('.dataTables_length select').select2({ minimumResultsForSearch: Infinity });
        $('.dataTables_filter input').addClass('form-control');
    });
</script> <?php /**PATH C:\laragon\www\gmpsarl.com\resources\views/components/script-datatable.blade.php ENDPATH**/ ?>