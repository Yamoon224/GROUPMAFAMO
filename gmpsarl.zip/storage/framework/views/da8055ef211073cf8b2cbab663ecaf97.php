<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo e(config('app.name', 'Laravel')); ?></title>

        <link rel="stylesheet" href="<?php echo e(asset('libs/nouislider/dist/nouislider.min.css')); ?>"/>
        <link rel="stylesheet" href="<?php echo e(asset('libs/drift-zoom/dist/drift-basic.min.css')); ?>" />

        <!-- Favicon icon-->
        <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('images/favicon.png')); ?>" />
        <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('images/favicon.png')); ?>" />
        <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('images/favicon.png')); ?>" />
        <link rel="manifest" href="<?php echo e(asset('images/favicon/site.webmanifest')); ?>" />
        <link rel="shortcut icon" href="<?php echo e(asset('images/favicon.png')); ?>" />

        <!-- Libs CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('libs/bootstrap-icons/font/bootstrap-icons.min.css')); ?>" />
        <link rel="stylesheet" href="<?php echo e(asset('libs/swiper/swiper-bundle.min.css')); ?>" />
        <link rel="stylesheet" href="<?php echo e(asset('libs/simplebar/dist/simplebar.min.css')); ?>" />
        <!-- Theme CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('css/theme.min.css')); ?>">
    </head>
    <body>
        <?php if (isset($component)) { $__componentOriginal5194778a3a7b899dcee5619d0610f5cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $attributes = $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $component = $__componentOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginalff09156f73c896030ee75284e9b2c466 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalff09156f73c896030ee75284e9b2c466 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.nav','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('nav'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalff09156f73c896030ee75284e9b2c466)): ?>
<?php $attributes = $__attributesOriginalff09156f73c896030ee75284e9b2c466; ?>
<?php unset($__attributesOriginalff09156f73c896030ee75284e9b2c466); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalff09156f73c896030ee75284e9b2c466)): ?>
<?php $component = $__componentOriginalff09156f73c896030ee75284e9b2c466; ?>
<?php unset($__componentOriginalff09156f73c896030ee75284e9b2c466); ?>
<?php endif; ?>

        <?php echo e($slot); ?>


        <?php if (isset($component)) { $__componentOriginal8a8716efb3c62a45938aca52e78e0322 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8a8716efb3c62a45938aca52e78e0322 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.footer','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8a8716efb3c62a45938aca52e78e0322)): ?>
<?php $attributes = $__attributesOriginal8a8716efb3c62a45938aca52e78e0322; ?>
<?php unset($__attributesOriginal8a8716efb3c62a45938aca52e78e0322); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8a8716efb3c62a45938aca52e78e0322)): ?>
<?php $component = $__componentOriginal8a8716efb3c62a45938aca52e78e0322; ?>
<?php unset($__componentOriginal8a8716efb3c62a45938aca52e78e0322); ?>
<?php endif; ?>

        <script src="<?php echo e(asset('libs/nouislider/dist/nouislider.min.js')); ?>"></script>
        <script src="<?php echo e(asset('libs/wnumb/wNumb.min.js')); ?>"></script>
        <!-- Libs JS -->
        <script src="<?php echo e(asset('libs/bootstrap/dist/js/bootstrap.bundle.min.js')); ?>"></script>
        <!-- Swiper JS -->
        <script src="<?php echo e(asset('libs/swiper/swiper-bundle.min.js')); ?>"></script>
        <script src="<?php echo e(asset('libs/simplebar/dist/simplebar.min.js')); ?>"></script>

        <!-- Theme JS -->
        <script src="<?php echo e(asset('js/theme.min.js')); ?>"></script>
        <script src="<?php echo e(asset('libs/choices.js/public/assets/scripts/choices.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/vendors/choice.js')); ?>"></script>
        <script src="<?php echo e(asset('js/vendors/flag.js')); ?>"></script>

        <script src="<?php echo e(asset('js/vendors/add-to-cart.js')); ?>"></script>
        <script src="<?php echo e(asset('js/vendors/qty-input.js')); ?>"></script>
        <script src="<?php echo e(asset('js/vendors/chechbox-filter.js')); ?>"></script>
        <script src="<?php echo e(asset('js/vendors/btn-scrolltop.js')); ?>"></script>
        <script src="<?php echo e(asset('js/vendors/color-change.js')); ?>"></script>
        <script src="<?php echo e(asset('libs/drift-zoom/dist/Drift.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/vendors/drift.js')); ?>"></script>
        <?php echo $__env->yieldPushContent('scripts'); ?>
    </body>
</html>
<?php /**PATH C:\laragon\www\gmpsarl.com\resources\views/layouts/guest.blade.php ENDPATH**/ ?>