<?php $__currentLoopData = $partners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="xl:w-1/4 lg:w-1/3 sm:w-1/3">
    <div class="card overflow-hidden">
        <div class="text-center p-4 relative z-[1] overlay-box" style="background-image: url(assets/images/big/img1.jpg);">
            <div class="profile-photo">
                <img src="assets/images/profile/profile.png" width="100" class="img-fluid rounded-full inline-block" alt="">
            </div>
            <h5 class="mt-4 mb-1 text-white"><?php echo e($item->company); ?></h5>
            <p class="text-white mb-0"><a href="<?php echo e(route('partners.show', $item->id)); ?>"><?php echo e($item->type); ?> <i class="fa fa-eye"></i></a></p>
        </div>
        <ul class="list-group flex flex-col list-group-flush">
            <li class="list-group-item flex p-4 text-body-color dark:text-white text-sm justify-between"><span class="mb-0"><?php echo app('translator')->get('locale.owner'); ?></span> <strong class=""><?php echo e($item->owner); ?></strong></li>
            <li class="list-group-item flex p-4 text-body-color dark:text-white text-sm justify-between"><span class="mb-0"><?php echo app('translator')->get('locale.phone'); ?></span> <strong class=""><?php echo e($item->phone); ?></strong></li>
        </ul>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\laragon\www\gmpsarl.com\resources\views/admin/partners/search.blade.php ENDPATH**/ ?>