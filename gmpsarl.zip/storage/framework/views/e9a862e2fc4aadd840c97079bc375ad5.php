<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startPush('links'); ?>
	<link href="<?php echo e(asset('vendor/datatables/css/jquery.dataTables.min.css')); ?>" rel="stylesheet">
    <?php $__env->stopPush(); ?>

    <div class="page-titles dark:bg-[#242424] flex items-center justify-between relative border-b border-[#E6E6E6] dark:border-[#444444] flex-wrap z-[1] py-[0.6rem] sm:px-[1.95rem] px-[1.55rem] bg-white">
        <ol class="text-[13px] flex items-center flex-wrap bg-transparent">
            <li>
                <a href="<?php echo e(route('dashboard')); ?>" class="text-[#828690] dark:text-white text-[13px]">
                    <svg class="mb-[3px] mr-1 inline-block" width="17" height="17" viewBox="0 0 17 17" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M2.125 6.375L8.5 1.41667L14.875 6.375V14.1667C14.875 14.5424 14.7257 14.9027 14.4601 15.1684C14.1944 15.4341 13.8341 15.5833 13.4583 15.5833H3.54167C3.16594 15.5833 2.80561 15.4341 2.53993 15.1684C2.27426 14.9027 2.125 14.5424 2.125 14.1667V6.375Z" stroke="#2C2C2C" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M6.375 15.5833V8.5H10.625V15.5833" stroke="#2C2C2C" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                    <?php echo app('translator')->get('locale.dashboard'); ?> 
                </a>
            </li>
            <li class="pl-2 before:content-['/'] before:font-[simple-line-icons] before:font-black before:text-xl before:leading-4 before:pr-2 before:float-left before:text-primary text-primary font-medium"><a><?php echo app('translator')->get('locale.room', ['suffix'=>'s']); ?></a></li>
        </ol>
        <a class="text-primary dark:text-white text-[0.8125rem] leading-[1.5]" href="<?php echo e(route('rooms.pdf')); ?>"><i class="fa fa-print"></i> <?php echo app('translator')->get('locale.pdf'); ?></a>
    </div>

    <div class="container-fluid">
        <div class="row">
            <div class="w-full">
                <div class="card overflow-hidden relative">
                    <div class="card-body p-0">
                        <div class="overflow-x-auto active-projects style-1">
                            <div class="tbl-caption flex justify-between items-center flex-wrap p-5 relative z-[2]">
                                <h4 class="max-sm:mb-2.5"><?php echo app('translator')->get('locale.room', ['suffix'=>'s']); ?></h4>
                                <div>
                                    <div class="icon-box w-[1.875rem] h-[1.875rem] leading-[1.7] inline-block relative text-center bg-secondary rounded-md mr-2">
                                        <a href="<?php echo e(route('rooms.card')); ?>">
                                            <svg width="20" height="20" viewBox="0 0 21 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M8.50032 3H2.66699V8.83333H8.50032V3Z" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                                <path d="M17.6668 3H11.8335V8.83333H17.6668V3Z" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                                <path d="M17.6668 12.1667H11.8335V18H17.6668V12.1667Z" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                                <path d="M8.50032 12.1667H2.66699V18H8.50032V12.1667Z" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                            </svg>
                                        </a>
                                    </div>
                                    <a class="rounded py-[5px] px-3 text-[13px] text-success bg-success leading-[18px] inline-block border border-success-light bg-success-light hover:text-white hover:bg-success offcanvas-toggle" data-dz-offcanvas="new-room">+ <?php echo app('translator')->get('locale.add'); ?></a>
                                </div>
                            </div>
                            <table id="empoloyees-tblwrapper" class="table">
                                <thead>
                                    <tr>
                                        <th class="text-[13px] py-2.5 pl-4 pr-0 bg-[#F0F4F9] text-[#374557] capitalize font-medium bg-none whitespace-nowrap text-left">#</th>
                                        <th class="text-[13px] py-2.5 px-4 bg-[#F0F4F9] text-[#374557] capitalize font-medium bg-none whitespace-nowrap text-left"><?php echo app('translator')->get('locale.room', ['suffix'=>'']); ?></th>
                                        <th class="text-[13px] py-2.5 px-4 bg-[#F0F4F9] text-[#374557] capitalize font-medium bg-none whitespace-nowrap text-left"><?php echo app('translator')->get('locale.nightly'); ?></th>
                                        <th class="text-[13px] py-2.5 px-4 bg-[#F0F4F9] text-[#374557] capitalize font-medium bg-none whitespace-nowrap text-left"><?php echo app('translator')->get('locale.status'); ?></th>
                                        <th class="text-[13px] py-2.5 px-4 bg-[#F0F4F9] text-[#374557] capitalize font-medium bg-none whitespace-nowrap text-left"><?php echo app('translator')->get('locale.image', ['suffix'=>'s']); ?></th>
                                        <th class="text-[13px] py-2.5 px-4 bg-[#F0F4F9] text-[#374557] capitalize font-medium bg-none whitespace-nowrap text-left"><?php echo app('translator')->get('locale.created_at'); ?></th>
                                        <th class="text-[13px] py-2.5 px-4 bg-[#F0F4F9] text-[#374557] capitalize font-medium bg-none whitespace-nowrap text-right"><?php echo app('translator')->get('locale.actions'); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="border-b border-[#E6E6E6] dark:border-[#444444] text-[13px] py-2.5 pl-4 pr-0 font-normal whitespace-nowrap">
                                            <span class="text-body-color dark:text-white text-[13px]"><?php echo e($loop->iteration); ?></span>
                                        </td>
                                        <td class="border-b border-[#E6E6E6] dark:border-[#444444] text-[13px] py-2.5 px-4 font-normal whitespace-nowrap">
                                            <div class="products flex items-center">
                                                <img src="<?php echo e(asset($item->front)); ?>" class="inline-block mr-2.5 w-[2.813rem] min-w-[2.813rem] h-[2.813rem] rounded-md relative object-cover avatar-md" alt="PHOTO">
                                                <div>
                                                    <h6 class="text-sm whitespace-nowrap"><?php echo e($item->type->type); ?></h6>
                                                    <span class="text-body-color dark:text-white text-xs"><?php echo e($item->name); ?></span>	
                                                </div>	
                                            </div>
                                        </td>
                                        <td class="border-b border-[#E6E6E6] dark:border-[#444444] text-[13px] py-2.5 px-4 font-normal whitespace-nowrap">
                                            <div>
                                                <h6 class="text-sm whitespace-nowrap"><?php echo e(moneyformat($item->price)); ?></h6>
                                                <span class="text-body-color dark:text-white text-xs"><?php echo e($item->address); ?></span>	
                                            </div>	
                                        </td>
                                        <td class="border-b border-[#E6E6E6] dark:border-[#444444] text-[13px] py-2.5 px-4 font-normal whitespace-nowrap">
                                            <div>
                                                <span class="text-xs py-[5px] px-3 rounded font-medium leading-[1.5] inline-block text-<?php echo e($item->isCurrentlyFree() ? 'success' : 'danger'); ?> bg-<?php echo e($item->isCurrentlyFree() ? 'success' : 'danger'); ?>-light"><i class="fa fa-bank"></i> <?php echo e($item->category); ?></span>
                                            </div>	
                                        </td>	
                                        <td class="border-b border-[#E6E6E6] dark:border-[#444444] text-[13px] py-2.5 px-4 font-normal whitespace-nowrap">
                                            <div class="avatar-list avatar-list-stacked">
                                                <?php $__currentLoopData = $item->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <img src="<?php echo e(asset($image->link ?? 'images/profile.png')); ?>" class="avatar inline-block w-[1.875rem] h-[1.875rem] me-[-13px] rounded-full border-2 border-white dark:border-[#444444] relative object-cover duration-300 hover:z-[1]" alt="PHOTO">
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        </td>
                                        <td class="border-b border-[#E6E6E6] dark:border-[#444444] text-[13px] py-2.5 px-4 font-normal whitespace-nowrap">
                                            <div>
                                                <h6 class="text-sm whitespace-nowrap"><?php echo e(date('d/m/Y H:i:s', strtotime($item->created_at))); ?></h6>
                                                <span class="text-xs py-[5px] px-3 rounded font-medium leading-[1.5] inline-block text-dark"><?php echo e(date('d/m/Y H:i:s', strtotime($item->updated_at))); ?></span>
                                            </div>	
                                        </td>	
                                        <td class="border-b border-[#E6E6E6] dark:border-[#444444] text-[13px] py-2.5 px-4 font-normal whitespace-nowrap text-right">
                                            <a class="rounded py-[5px] px-3 text-[13px] text-primary bg-primary leading-[18px] inline-block border border-primary-light bg-primary-light hover:text-white hover:bg-primary" href="<?php echo e(route('rooms.show', $item->id)); ?>" style="display: inline-block"><i class="fa fa-eye"></i></a>
                                            <a class="rounded py-[5px] px-3 text-[13px] text-primary bg-primary leading-[18px] inline-block border border-primary-light bg-primary-light hover:text-white hover:bg-primary" href="<?php echo e(route('rooms.edit', $item->id)); ?>" style="display: inline-block"><i class="fa fa-edit"></i></a>
                                            <form action="<?php echo e(route('rooms.destroy', $item->id)); ?>" method="post" style="display: inline-block">
                                                <?php echo method_field('DELETE'); ?> <?php echo csrf_field(); ?>
                                                <button class="rounded py-[5px] px-3 text-[13px] text-danger bg-danger leading-[18px] inline-block border border-danger-light bg-danger-light hover:text-white hover:bg-danger" onclick="if(!confirm('Confirmez-Vous cette Suppression ?')) return false"><i class="fa fa-trash"></i></button>
                                            </form>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php if (isset($component)) { $__componentOriginal606405c1e1665cc5d04503217d8e7f29 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal606405c1e1665cc5d04503217d8e7f29 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.add-room','data' => ['types' => $types]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('add-room'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['types' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($types)]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal606405c1e1665cc5d04503217d8e7f29)): ?>
<?php $attributes = $__attributesOriginal606405c1e1665cc5d04503217d8e7f29; ?>
<?php unset($__attributesOriginal606405c1e1665cc5d04503217d8e7f29); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal606405c1e1665cc5d04503217d8e7f29)): ?>
<?php $component = $__componentOriginal606405c1e1665cc5d04503217d8e7f29; ?>
<?php unset($__componentOriginal606405c1e1665cc5d04503217d8e7f29); ?>
<?php endif; ?>
    <?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('vendor/chart.js/chart.bundle.min.js')); ?>"></script>
	
	<script src="<?php echo e(asset('vendor/datatables/js/jquery.dataTables.min.js')); ?>"></script>
	<script src="<?php echo e(asset('vendor/datatables/js/dataTables.buttons.min.js')); ?>"></script>
	<script src="<?php echo e(asset('vendor/datatables/js/buttons.html5.min.js')); ?>"></script>
	<script src="<?php echo e(asset('vendor/datatables/js/jszip.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/plugins-init/datatables.init.min.js')); ?>"></script>
	<script src="<?php echo e(asset('vendor/tagify/dist/tagify.min.js')); ?>"></script>
	<script src="<?php echo e(asset('vendor/niceselect/js/jquery.nice-select.min.js')); ?>"></script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>

<?php /**PATH C:\laragon\www\gmpsarl.com\resources\views/admin/rooms/index.blade.php ENDPATH**/ ?>