<nav class="nxl-navigation">
    <div class="navbar-wrapper">
        <div class="m-header">
            <a href="<?php echo e(route('dashboard')); ?>" class="b-brand d-flex justify-content-center">
                <img src="<?php echo e(asset('images/logo.png')); ?>" alt="LOGO" class="mx-auto logo logo-lg" height="60" width="80" />
                <img src="<?php echo e(asset('images/logo.png')); ?>" alt="LOGO" class="logo logo-sm" />
            </a>
        </div>
        <div class="navbar-content">
            <ul class="nxl-navbar">
                <li class="nxl-item nxl-caption">
                    <label>Menu</label>
                </li>
                <li class="nxl-item nxl-hasmenu">
                    <a href="<?php echo e(route('dashboard')); ?>" class="nxl-link">
                        <span class="nxl-micon"><i class="feather-airplay"></i></span>
                        <span class="nxl-mtext"><?php echo app('translator')->get('locale.dashboard'); ?></span>
                    </a>
                </li>
                <li class="nxl-item nxl-hasmenu">
                    <a href="javascript:void(0);" class="nxl-link">
                        <span class="nxl-micon"><i class="feather-briefcase"></i></span>
                        <span class="nxl-mtext"><?php echo app('translator')->get('locale.contract', ['suffix'=>'s']); ?></span><span class="nxl-arrow"><i class="feather-chevron-right"></i></span>
                    </a>
                    <ul class="nxl-submenu">
                        <li class="nxl-item"><a class="nxl-link" href="<?php echo e(route('categories.index')); ?>"><?php echo app('translator')->get('locale.category', ['suffix'=>app()->getLocale() == 'en' ? 'ies' : 's']); ?></a></li>
                        <li class="nxl-item"><a class="nxl-link" href="<?php echo e(route('partners.index')); ?>"><?php echo app('translator')->get('locale.partner', ['suffix'=>'s']); ?></a></li>
                        <li class="nxl-item"><a class="nxl-link" href="<?php echo e(route('contracts.index')); ?>"><?php echo app('translator')->get('locale.contract', ['suffix'=>'s']); ?></a></li>
                    </ul>
                </li>
                <li class="nxl-item nxl-hasmenu">
                    <a href="javascript:void(0);" class="nxl-link">
                        <span class="nxl-micon"><i class="feather-send"></i></span>
                        <span class="nxl-mtext">Applications</span><span class="nxl-arrow"><i class="feather-chevron-right"></i></span>
                    </a>
                    <ul class="nxl-submenu">
                        <li class="nxl-item"><a class="nxl-link" href="apps-chat.html">Chat</a></li>
                        <li class="nxl-item"><a class="nxl-link" href="apps-email.html">Email</a></li>
                        <li class="nxl-item"><a class="nxl-link" href="apps-tasks.html">Tasks</a></li>
                        <li class="nxl-item"><a class="nxl-link" href="apps-notes.html">Notes</a></li>
                        <li class="nxl-item"><a class="nxl-link" href="apps-storage.html">Storage</a></li>
                        <li class="nxl-item"><a class="nxl-link" href="apps-calendar.html">Calendar</a></li>
                    </ul>
                </li>
                <li class="nxl-item nxl-hasmenu">
                    <a href="javascript:void(0);" class="nxl-link">
                        <span class="nxl-micon"><i class="feather-at-sign"></i></span>
                        <span class="nxl-mtext">Proposal</span><span class="nxl-arrow"><i class="feather-chevron-right"></i></span>
                    </a>
                    <ul class="nxl-submenu">
                        <li class="nxl-item"><a class="nxl-link" href="proposal.html">Proposal</a></li>
                        <li class="nxl-item"><a class="nxl-link" href="proposal-view.html">Proposal View</a></li>
                        <li class="nxl-item"><a class="nxl-link" href="proposal-edit.html">Proposal Edit</a></li>
                        <li class="nxl-item"><a class="nxl-link" href="proposal-create.html">Proposal Create</a></li>
                    </ul>
                </li>
                <li class="nxl-item nxl-hasmenu">
                    <a href="javascript:void(0);" class="nxl-link">
                        <span class="nxl-micon"><i class="feather-dollar-sign"></i></span>
                        <span class="nxl-mtext">Payment</span><span class="nxl-arrow"><i class="feather-chevron-right"></i></span>
                    </a>
                    <ul class="nxl-submenu">
                        <li class="nxl-item"><a class="nxl-link" href="payment.html">Payment</a></li>
                        <li class="nxl-item"><a class="nxl-link" href="invoice-view.html">Invoice View</a></li>
                        <li class="nxl-item"><a class="nxl-link" href="invoice-create.html">Invoice Create</a></li>
                    </ul>
                </li>
                <li class="nxl-item nxl-hasmenu">
                    <a href="javascript:void(0);" class="nxl-link">
                        <span class="nxl-micon"><i class="feather-users"></i></span>
                        <span class="nxl-mtext">Customers</span><span class="nxl-arrow"><i class="feather-chevron-right"></i></span>
                    </a>
                    <ul class="nxl-submenu">
                        <li class="nxl-item"><a class="nxl-link" href="customers.html">Customers</a></li>
                        <li class="nxl-item"><a class="nxl-link" href="customers-view.html">Customers View</a></li>
                        <li class="nxl-item"><a class="nxl-link" href="customers-create.html">Customers Create</a></li>
                    </ul>
                </li>
                <li class="nxl-item nxl-hasmenu">
                    <a href="javascript:void(0);" class="nxl-link">
                        <span class="nxl-micon"><i class="feather-alert-circle"></i></span>
                        <span class="nxl-mtext">Leads</span><span class="nxl-arrow"><i class="feather-chevron-right"></i></span>
                    </a>
                    <ul class="nxl-submenu">
                        <li class="nxl-item"><a class="nxl-link" href="leads.html">Leads</a></li>
                        <li class="nxl-item"><a class="nxl-link" href="leads-view.html">Leads View</a></li>
                        <li class="nxl-item"><a class="nxl-link" href="leads-create.html">Leads Create</a></li>
                    </ul>
                </li>
                <li class="nxl-item nxl-hasmenu">
                    <a href="javascript:void(0);" class="nxl-link">
                        <span class="nxl-micon"><i class="feather-briefcase"></i></span>
                        <span class="nxl-mtext">Projects</span><span class="nxl-arrow"><i class="feather-chevron-right"></i></span>
                    </a>
                    <ul class="nxl-submenu">
                        <li class="nxl-item"><a class="nxl-link" href="projects.html">Projects</a></li>
                        <li class="nxl-item"><a class="nxl-link" href="projects-view.html">Projects View</a></li>
                        <li class="nxl-item"><a class="nxl-link" href="projects-create.html">Projects Create</a></li>
                    </ul>
                </li>
                <li class="nxl-item nxl-hasmenu">
                    <a href="javascript:void(0);" class="nxl-link">
                        <span class="nxl-micon"><i class="feather-layout"></i></span>
                        <span class="nxl-mtext">Widgets</span><span class="nxl-arrow"><i class="feather-chevron-right"></i></span>
                    </a>
                    <ul class="nxl-submenu">
                        <li class="nxl-item"><a class="nxl-link" href="widgets-lists.html">Lists</a></li>
                        <li class="nxl-item"><a class="nxl-link" href="widgets-tables.html">Tables</a></li>
                        <li class="nxl-item"><a class="nxl-link" href="widgets-charts.html">Charts</a></li>
                        <li class="nxl-item"><a class="nxl-link" href="widgets-statistics.html">Statistics</a></li>
                        <li class="nxl-item"><a class="nxl-link" href="widgets-miscellaneous.html">Miscellaneous</a></li>
                    </ul>
                </li>
                <li class="nxl-item nxl-hasmenu">
                    <a href="javascript:void(0);" class="nxl-link">
                        <span class="nxl-micon"><i class="feather-settings"></i></span>
                        <span class="nxl-mtext">Settings</span><span class="nxl-arrow"><i class="feather-chevron-right"></i></span>
                    </a>
                    <ul class="nxl-submenu">
                        <li class="nxl-item"><a class="nxl-link" href="settings-general.html">General</a></li>
                        <li class="nxl-item"><a class="nxl-link" href="settings-seo.html">SEO</a></li>
                        <li class="nxl-item"><a class="nxl-link" href="settings-tags.html">Tags</a></li>
                        <li class="nxl-item"><a class="nxl-link" href="settings-email.html">Email</a></li>
                        <li class="nxl-item"><a class="nxl-link" href="settings-tasks.html">Tasks</a></li>
                        <li class="nxl-item"><a class="nxl-link" href="settings-leads.html">Leads</a></li>
                        <li class="nxl-item"><a class="nxl-link" href="settings-support.html">Support</a></li>
                        <li class="nxl-item"><a class="nxl-link" href="settings-finance.html">Finance</a></li>
                        <li class="nxl-item"><a class="nxl-link" href="settings-gateways.html">Gateways</a></li>
                        <li class="nxl-item"><a class="nxl-link" href="settings-customers.html">Customers</a></li>
                        <li class="nxl-item"><a class="nxl-link" href="settings-localization.html">Localization</a></li>
                        <li class="nxl-item"><a class="nxl-link" href="settings-recaptcha.html">reCAPTCHA</a></li>
                        <li class="nxl-item"><a class="nxl-link" href="settings-miscellaneous.html">Miscellaneous</a></li>
                    </ul>
                </li>
                <li class="nxl-item nxl-hasmenu">
                    <a href="<?php echo e(route('logout')); ?>" class="nxl-link text-danger">
                        <span class="nxl-micon"><i class="feather-power"></i></span>
                        <span class="nxl-mtext"><?php echo app('translator')->get('locale.logout'); ?></span>
                    </a>
                </li>
                
            </ul>
            <div class="card text-center">
                <div class="card-body">
                    <img src="<?php echo e(asset('images/conceptor.png')); ?>" alt="EDITOSYSTEM" height="25" width="25" class="fs-4 img-fluid">
                    <h6 class="mt-2 text-dark fw-bolder"><?php echo e(env('APP_CONCEPTOR')); ?></h6>
                    <p class="fs-11 my-2 text-dark text-justify"><?php echo app('translator')->get('locale.devconcept'); ?></p>
                    <a href="javascript:void(0);" class="btn btn-primary text-dark w-100"><?php echo app('translator')->get('locale.link'); ?></a>
                </div>
            </div>
        </div>
    </div>
</nav><?php /**PATH C:\laragon\www\gmpsarl.com\resources\views/components/app-nav.blade.php ENDPATH**/ ?>