<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="page-titles dark:bg-[#242424] flex items-center justify-between relative border-b border-[#E6E6E6] dark:border-[#444444] flex-wrap z-[1] py-[0.6rem] sm:px-[1.95rem] px-[1.55rem] bg-white">
        <ol class="text-[13px] flex items-center flex-wrap bg-transparent">
            <li>
                <a href="<?php echo e(route('rooms.index')); ?>" class="text-[#828690] dark:text-white text-[13px]">
                    <svg class="mb-[3px] mr-1 inline-block" width="17" height="17" viewBox="0 0 17 17" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M2.125 6.375L8.5 1.41667L14.875 6.375V14.1667C14.875 14.5424 14.7257 14.9027 14.4601 15.1684C14.1944 15.4341 13.8341 15.5833 13.4583 15.5833H3.54167C3.16594 15.5833 2.80561 15.4341 2.53993 15.1684C2.27426 14.9027 2.125 14.5424 2.125 14.1667V6.375Z" stroke="#2C2C2C" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M6.375 15.5833V8.5H10.625V15.5833" stroke="#2C2C2C" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                    <?php echo app('translator')->get('locale.room', ['suffix'=>'s']); ?> 
                </a>
            </li>
            <li class="pl-2 before:content-['/'] before:font-[simple-line-icons] before:font-black before:text-xl before:leading-4 before:pr-2 before:float-left before:text-primary text-primary font-medium"><a><?php echo e($room->name); ?></a></li>
        </ol>
    </div>

    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body relative p-[1.875rem]">
                        <form action="<?php echo e(route('rooms.update', $room->id)); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                            <div class="row">	
                                <div class="xl:w-1/2 mb-4 mx-auto">
                                    <label class="form-label"><?php echo app('translator')->get('locale.type', ['suffix'=>'']); ?><span class="text-danger">*</span></label>
                                    <select name="type_id" class="nice-select style-1 py-1.5 px-3 bg-transparent text-[13px] font-normal outline-none relative focus:ring-0 border border-b-color text-[#a5a5a5] h-[2.813rem] leading-[1.813rem]" required>
                                        <option data-display="<?php echo app('translator')->get('locale.select'); ?>"><?php echo app('translator')->get('locale.select'); ?></option>
                                        <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option <?php echo e($item->id == $room->type_id ? 'selected' : ''); ?> value="<?php echo e($item->id); ?>"><?php echo e($item->type); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="xl:w-1/2 mb-4">
                                    <label class="form-label"><?php echo app('translator')->get('locale.category', ['suffix'=>app()->getLocale() == 'en' ? 'y' : '']); ?><span class="text-danger">*</span></label>
                                    <select name="category" class="nice-select style-1 py-1.5 px-3 bg-transparent text-[13px] font-normal outline-none relative focus:ring-0 border border-b-color text-[#a5a5a5] h-[2.813rem] leading-[1.813rem]" required>
                                        <option data-display="<?php echo app('translator')->get('locale.select'); ?>" value=""><?php echo app('translator')->get('locale.select'); ?></option>
                                        <?php $__currentLoopData = ['SEJOUR', 'LOCATION', 'VENTE']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option <?php echo e($item == $room->category ? 'selected' : ''); ?> ><?php echo e($item); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="xl:w-full mb-4 mx-auto">
                                    <label for="name" class="form-label"><?php echo app('translator')->get('locale.name'); ?> <span class="text-danger">*</span></label>
                                    <input type="text" name="name" value="<?php echo e($room->name); ?>" class="form-control relative text-[13px] text-body-color h-[2.813rem] border border-b-color block rounded-md py-1.5 px-3 duration-500 focus:border-primary dark:hover:border-b-color outline-none w-full" id="name" placeholder="<?php echo app('translator')->get('locale.name'); ?>" required>
                                </div>	
                                <div class="xl:w-1/2 mb-4 mx-auto">
                                    <label for="address" class="form-label"><?php echo app('translator')->get('locale.address'); ?> <span class="text-danger">*</span></label>
                                    <input type="text" name="address" value="<?php echo e($room->address); ?>" class="form-control relative text-[13px] text-body-color h-[2.813rem] border border-b-color block rounded-md py-1.5 px-3 duration-500 focus:border-primary dark:hover:border-b-color outline-none w-full" id="address" placeholder="<?php echo app('translator')->get('locale.address'); ?>" required>
                                </div>
                                <div class="xl:w-1/2 mb-4 mx-auto">
                                    <label for="price" class="form-label"><?php echo app('translator')->get('locale.nightly'); ?> <span class="text-danger">*</span></label>
                                    <input type="number" name="price" value="<?php echo e($room->price); ?>" class="form-control relative text-[13px] text-body-color h-[2.813rem] border border-b-color block rounded-md py-1.5 px-3 duration-500 focus:border-primary dark:hover:border-b-color outline-none w-full" id="price" placeholder="<?php echo app('translator')->get('locale.nightly'); ?>" required>
                                </div>
                                <div class="xl:w-1/2 mb-4">
                                    <label for="front" class="form-label"><?php echo app('translator')->get('locale.photo'); ?> I</label>
                                    <input type="file" name="front" accept=".png, .jpg, .jpep" class="form-control relative text-[13px] text-body-color h-[2.813rem] border border-b-color block rounded-md py-1.5 px-3 duration-500 focus:border-primary dark:hover:border-b-color outline-none w-full" id="front" placeholder="<?php echo app('translator')->get('locale.photo'); ?>">
                                </div>
                                <div class="xl:w-1/2 mb-4">
                                    <label for="back" class="form-label"><?php echo app('translator')->get('locale.photo'); ?> II</label>
                                    <input type="file" name="back" accept=".png, .jpg, .jpep" class="form-control relative text-[13px] text-body-color h-[2.813rem] border border-b-color block rounded-md py-1.5 px-3 duration-500 focus:border-primary dark:hover:border-b-color outline-none w-full" id="back" placeholder="<?php echo app('translator')->get('locale.photo'); ?>">
                                </div>
                                <div class="w-full mb-3">
                                    <label class="form-label"><?php echo app('translator')->get('locale.description'); ?></label>
                                    <textarea rows="3" name="description" style="resize: none" class="form-control relative text-[13px] h-auto min-h-auto border border-b-color block rounded-md p-3 duration-500 focus:border-primary dark:hover:border-b-color outline-none w-full resize-y"><?php echo e($room->description); ?></textarea>
                                </div>	
                                <div class="w-full justify-end">
                                    <button class="rounded py-[5px] px-3 text-[13px] text-primary bg-primary leading-[18px] inline-block border border-primary-light bg-primary-light hover:text-white hover:bg-primary"><?php echo app('translator')->get('locale.submit'); ?></button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php $__env->startPush('scripts'); ?>
	<script src="<?php echo e(asset('vendor/niceselect/js/jquery.nice-select.min.js')); ?>"></script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>

<?php /**PATH C:\laragon\www\gmpsarl.com\resources\views/admin/rooms/edit.blade.php ENDPATH**/ ?>