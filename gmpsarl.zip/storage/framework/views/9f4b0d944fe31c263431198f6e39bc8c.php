<?php if (isset($component)) { $__componentOriginala6488acc797ee40bc55ed6344dee8ea1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala6488acc797ee40bc55ed6344dee8ea1 = $attributes; } ?>
<?php $component = App\View\Components\AuthLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('auth-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AuthLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="text-center">
        <h3 class="title mb-2"><?php echo app('translator')->get('locale.sign_in'); ?></h3>
        <p class="mb-4"><?php echo e(!empty($errors) && !empty($errors->all()) ? implode('', $errors->all()) : (session('status') ? session('status') : "")); ?></p>
    </div>
    <form action="<?php echo e(route('login')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label class="mb-1 text-dark"><?php echo app('translator')->get('locale.email'); ?> / <?php echo app('translator')->get('locale.phone'); ?></label>
            <input type="text" name="email" class="form-control relative text-[13px] text-body-color h-[2.813rem] border border-b-color block rounded-md py-1.5 px-3 duration-500 focus:border-primary dark:hover:border-b-color outline-none w-full" placeholder="email@gmpsarl.com | 624568790" required>
        </div>
        <div class="mb-3 relative">
            <label class="mb-1 text-dark"><?php echo app('translator')->get('locale.password'); ?></label>
            <input type="password" id="dz-password" class="form-control relative text-[13px] h-[2.813rem] border border-b-color block rounded-md py-1.5 px-3 duration-500 focus:border-primary dark:hover:border-b-color outline-none w-full text-body-color" placeholder="<?php echo app('translator')->get('locale.password'); ?>" name="password" required>
            <span class="show-pass eye absolute right-5 bottom-[10px] text-body-color cursor-pointer">
                <i class="fa fa-eye-slash"></i>
                <i class="fa fa-eye"></i>
            </span>
        </div>
        <div class="form-row flex justify-between mt-2">
            <div>
                <div class="leading-normal block min-h-[1.3125rem] pl-[1.5em] custom-checkbox mb-4 whitespace-nowrap">
                    <input type="checkbox" class="form-check-input ml-[-1.5em]" id="rememberme" name="remember">
                    <label class="mt-[5px] text-body-color ml-[0.3125rem]" for="rememberme"><?php echo app('translator')->get('locale.remember_me'); ?></label>
                </div>
            </div>
            <?php if(Route::has('password.request')): ?>
            <div>
                <a href="<?php echo e(route('password.request')); ?>" class="sm:text-sm text-xs text-primary whitespace-nowrap dark:text-white"><?php echo app('translator')->get('locale.forgot_pwd'); ?></a>
            </div>
            <?php endif; ?>
        </div>
        <div class="text-center mb-2">
            <button class="block w-full rounded font-medium text-[15px] max-xl:text-xs leading-5 py-[0.719rem] max-xl:px-4 px-[1.563rem] max-xl:py-2.5 border border-primary text-white bg-primary hover:bg-hover-primary hover:border-hover-primary duration-300 mb-2"><?php echo app('translator')->get('locale.submit'); ?></button>
        </div>
    </form>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala6488acc797ee40bc55ed6344dee8ea1)): ?>
<?php $attributes = $__attributesOriginala6488acc797ee40bc55ed6344dee8ea1; ?>
<?php unset($__attributesOriginala6488acc797ee40bc55ed6344dee8ea1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala6488acc797ee40bc55ed6344dee8ea1)): ?>
<?php $component = $__componentOriginala6488acc797ee40bc55ed6344dee8ea1; ?>
<?php unset($__componentOriginala6488acc797ee40bc55ed6344dee8ea1); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\gmpsarl.com\resources\views/auth/login.blade.php ENDPATH**/ ?>