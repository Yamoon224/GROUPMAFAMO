<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta content="AJS" name="author"/>
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <meta content="APP GESTION CLINIQUE" name="description"/>
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <meta content="APP GESTION DES CONTRATS BTP ET GESTION DES SERVICES IMMOBILIERS" name="description"/>
        <meta property="og:title" content="W3CRM - Customer Relationship Management Tailwind CSS Admin Dashboard Template | DexignZone">
        <meta property="og:description" content="W3Crm offers a powerful Customer Relationship Management (CRM) Admin Dashboard, empowering businesses to streamline interactions, track leads, and enhance customer satisfaction. Manage contacts, automate tasks, and analyze data effortlessly with W3Crm's intuitive interface.">
        <meta property="og:image" content="https://w3crm.dexignzone.com/tailwind/social-image.png">

        <meta name="format-detection" content="telephone=no">

        <meta name="twitter:title" content="APP WEB ERP GROUP MAFAMO PRESS SARL">
        <meta name="twitter:description" content="APP GESTION DES CONTRATS BTP ET GESTION DES SERVICES IMMOBILIERS">
        <meta name="twitter:image" content="https://w3crm.dexignzone.com/tailwind/social-image.png">
        <meta name="twitter:card" content="summary_large_image">
        
        <title><?php echo e(config('app.name', 'GMPSARL')); ?></title>
        <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('images/favicon.png')); ?>">  

        <link rel="stylesheet" href="<?php echo e(asset('icons/fontawesome/css/all.min.css')); ?>">

        <?php echo $__env->yieldPushContent('links'); ?>

        <link href="<?php echo e(asset('vendor/niceselect/css/nice-select.css')); ?>" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css2?family=Material+Icons" rel="stylesheet">
        <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
    </head>
    <body class="selection:text-white selection:bg-primary">
        <?php if (isset($component)) { $__componentOriginalcfeb5813eb5e125a185268bd877f5256 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcfeb5813eb5e125a185268bd877f5256 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-preloader','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-preloader'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcfeb5813eb5e125a185268bd877f5256)): ?>
<?php $attributes = $__attributesOriginalcfeb5813eb5e125a185268bd877f5256; ?>
<?php unset($__attributesOriginalcfeb5813eb5e125a185268bd877f5256); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcfeb5813eb5e125a185268bd877f5256)): ?>
<?php $component = $__componentOriginalcfeb5813eb5e125a185268bd877f5256; ?>
<?php unset($__componentOriginalcfeb5813eb5e125a185268bd877f5256); ?>
<?php endif; ?>
        
        <div id="main-wrapper">
            <?php if (isset($component)) { $__componentOriginale5c4f6cd31270d2b7ac180b35c2b824a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale5c4f6cd31270d2b7ac180b35c2b824a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-navheader','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-navheader'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale5c4f6cd31270d2b7ac180b35c2b824a)): ?>
<?php $attributes = $__attributesOriginale5c4f6cd31270d2b7ac180b35c2b824a; ?>
<?php unset($__attributesOriginale5c4f6cd31270d2b7ac180b35c2b824a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale5c4f6cd31270d2b7ac180b35c2b824a)): ?>
<?php $component = $__componentOriginale5c4f6cd31270d2b7ac180b35c2b824a; ?>
<?php unset($__componentOriginale5c4f6cd31270d2b7ac180b35c2b824a); ?>
<?php endif; ?>

            <?php if (isset($component)) { $__componentOriginal298e27b3934364697cffdda7680287c9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal298e27b3934364697cffdda7680287c9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-chatbox','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-chatbox'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal298e27b3934364697cffdda7680287c9)): ?>
<?php $attributes = $__attributesOriginal298e27b3934364697cffdda7680287c9; ?>
<?php unset($__attributesOriginal298e27b3934364697cffdda7680287c9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal298e27b3934364697cffdda7680287c9)): ?>
<?php $component = $__componentOriginal298e27b3934364697cffdda7680287c9; ?>
<?php unset($__componentOriginal298e27b3934364697cffdda7680287c9); ?>
<?php endif; ?>

            <?php if (isset($component)) { $__componentOriginal5d959a11ff826b3fd89e60f60adf4cb2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5d959a11ff826b3fd89e60f60adf4cb2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-header','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5d959a11ff826b3fd89e60f60adf4cb2)): ?>
<?php $attributes = $__attributesOriginal5d959a11ff826b3fd89e60f60adf4cb2; ?>
<?php unset($__attributesOriginal5d959a11ff826b3fd89e60f60adf4cb2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5d959a11ff826b3fd89e60f60adf4cb2)): ?>
<?php $component = $__componentOriginal5d959a11ff826b3fd89e60f60adf4cb2; ?>
<?php unset($__componentOriginal5d959a11ff826b3fd89e60f60adf4cb2); ?>
<?php endif; ?>

            <?php if (isset($component)) { $__componentOriginal217379be201db1df72e57af0da64bc10 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal217379be201db1df72e57af0da64bc10 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-deznav','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-deznav'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal217379be201db1df72e57af0da64bc10)): ?>
<?php $attributes = $__attributesOriginal217379be201db1df72e57af0da64bc10; ?>
<?php unset($__attributesOriginal217379be201db1df72e57af0da64bc10); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal217379be201db1df72e57af0da64bc10)): ?>
<?php $component = $__componentOriginal217379be201db1df72e57af0da64bc10; ?>
<?php unset($__componentOriginal217379be201db1df72e57af0da64bc10); ?>
<?php endif; ?>

            <div class="content-body">
                <?php echo e($slot); ?>

            </div>
            <?php if (isset($component)) { $__componentOriginaldc1d412241c83c27fa88e22bcda07d14 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldc1d412241c83c27fa88e22bcda07d14 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-others','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-others'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldc1d412241c83c27fa88e22bcda07d14)): ?>
<?php $attributes = $__attributesOriginaldc1d412241c83c27fa88e22bcda07d14; ?>
<?php unset($__attributesOriginaldc1d412241c83c27fa88e22bcda07d14); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldc1d412241c83c27fa88e22bcda07d14)): ?>
<?php $component = $__componentOriginaldc1d412241c83c27fa88e22bcda07d14; ?>
<?php unset($__componentOriginaldc1d412241c83c27fa88e22bcda07d14); ?>
<?php endif; ?>

            <?php if (isset($component)) { $__componentOriginal868091fdcca1b7cd44d9608210d3c88a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal868091fdcca1b7cd44d9608210d3c88a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-footer','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal868091fdcca1b7cd44d9608210d3c88a)): ?>
<?php $attributes = $__attributesOriginal868091fdcca1b7cd44d9608210d3c88a; ?>
<?php unset($__attributesOriginal868091fdcca1b7cd44d9608210d3c88a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal868091fdcca1b7cd44d9608210d3c88a)): ?>
<?php $component = $__componentOriginal868091fdcca1b7cd44d9608210d3c88a; ?>
<?php unset($__componentOriginal868091fdcca1b7cd44d9608210d3c88a); ?>
<?php endif; ?>
        </main>


        <script src="<?php echo e(asset('vendor/global/global.min.js')); ?>"></script>
        <?php echo $__env->yieldPushContent('scripts'); ?>       
        <script src="<?php echo e(asset('js/deznav-init.js')); ?>"></script>
        <script src="<?php echo e(asset('js/custom.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/styleSwitcher.js')); ?>"></script>
        <script src="<?php echo e(asset('js/demo.min.js')); ?>"></script>
    </body>
</html>
<?php /**PATH C:\laragon\www\gmpsarl.com\resources\views/layouts/app.blade.php ENDPATH**/ ?>