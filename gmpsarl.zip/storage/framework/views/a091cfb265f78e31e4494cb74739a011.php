<button <?php echo e($attributes->merge(['type' => 'submit', 'class' => 'btn'])); ?>>
    <?php echo e($slot); ?>

</button>
<?php /**PATH C:\laragon\www\gmpsarl.com\resources\views/components/app-button.blade.php ENDPATH**/ ?>