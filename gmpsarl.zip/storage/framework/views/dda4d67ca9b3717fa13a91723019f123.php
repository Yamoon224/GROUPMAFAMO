<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startPush('links'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('icons/line-awesome/css/line-awesome.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('icons/simple-line-icons/css/simple-line-icons.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('icons/themify-icons/css/themify-icons.css')); ?>">	
    <link rel="stylesheet" href="<?php echo e(asset('vendor/select2/css/select2.min.css')); ?>">
    <?php $__env->stopPush(); ?>

    <!-- row -->	
    <div class="page-titles dark:bg-[#242424] flex items-center justify-between relative border-b border-[#E6E6E6] dark:border-[#444444] flex-wrap z-[1] py-[0.6rem] sm:px-[1.95rem] px-[1.55rem] bg-white">
        <ol class="text-[13px] flex items-center flex-wrap bg-transparent">
            <li><a href="<?php echo e(route('contracts.index')); ?>" class="text-[#828690] dark:text-white text-[13px]"><?php echo app('translator')->get('locale.contract', ['suffix'=>'s']); ?></a></li>
            <li class="pl-2 before:content-['/'] before:font-[simple-line-icons] before:font-black before:text-xl before:leading-4 before:pr-2 before:float-left before:text-primary text-primary font-medium"><a><?php echo app('translator')->get('locale.edit', ['param'=>__('locale.contract', ['suffix'=>''])]); ?></a></li>
        </ol>
    </div>
    <div class="container-fluid">
        <div class="row">
            <div class="w-full col-xxl-12">
                <div class="card">
                    <div class="card-header flex flex-wrap justify-between items-center sm:p-5 sm:pt-6 p-4 pt-5 max-sm:pb-5 relative border-b border-[#E6E6E6] dark:border-[#444444]">
                        <h4 class="card-title capitalize"><?php echo app('translator')->get('locale.edit', ['param'=>__('locale.contract', ['suffix'=>''])]); ?></h4>
                    </div>
                    <div class="sm:p-5 p-4">
                        <form action="<?php echo e(route('contracts.update', $contract->id)); ?>" method="post">
                            <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                            <div class="accordion accordion-primary accordion-wrapper">
                                <div class="accordion-item mb-2">
                                    <div class="accordion-header dark:text-white bg-primary-light text-primary py-[0.7rem] px-3 border border-transparent rounded-md relative cursor-pointer text-sm duration-500 accordion-btn active" data-dz-item="collapseOne">
                                        <span class="accordion-header-icon"></span>
                                        <span class="accordion-header-text"><?php echo app('translator')->get('locale.contract', ['suffix'=>'']); ?></span>
                                        <span class="accordion-header-indicator"></span>
                                    </div>
                                    <div id="collapseOne" class="accordion-content">
                                        <div class="accordion-body-text py-3.5 px-3 sm:text-sm text-xs text-body-color">
                                            <div class="row">
                                                <div class="lg:w-1/2 mb-2">
                                                    <div class="mb-4">
                                                        <label class="text-body-color dark:text-white"><?php echo app('translator')->get('locale.category', ['suffix'=>app()->getLocale() == 'en' ? 'y' : '']); ?> <span class="required text-danger">*</span></label>
                                                        <select class="single-select" name="contract[category_id]" required>
                                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($item->id); ?>" <?php echo e($contract->category_id == $item->id ? 'selected' : ''); ?>><?php echo e($item->category); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="lg:w-1/2 mb-2">
                                                    <div class="mb-4">
                                                        <label class="text-body-color dark:text-white"><?php echo app('translator')->get('locale.partner', ['suffix'=>'']); ?> <span class="required text-danger">*</span></label>
                                                        <select class="single-select" name="contract[partner_id]" required>
                                                            <?php $__currentLoopData = $partners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($item->id); ?>" <?php echo e($contract->partner_id == $item->id ? 'selected' : ''); ?>><?php echo e($item->type.' : '.$item->company); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="lg:w-full mb-2">
                                                    <div class="mb-4">
                                                        <label class="text-body-color dark:text-white"><?php echo app('translator')->get('locale.title'); ?> <span class="required text-danger">*</span></label>
                                                        <input type="text" name="contract[title]" value="<?php echo e($contract->title); ?>" class="relative text-[13px] h-[2.813rem] border border-b-color block rounded-md py-1.5 px-3 duration-500 focus:border-primary dark:hover:border-b-color outline-none w-full" placeholder="<?php echo app('translator')->get('locale.title'); ?>" required>
                                                    </div>
                                                </div>
                                                <div class="lg:w-1/2 mb-2">
                                                    <div class="mb-4">
                                                        <label class="text-body-color dark:text-white"><?php echo app('translator')->get('locale.cost'); ?> <span class="required text-danger">*</span></label>
                                                        <input type="number" name="contract[cost]" value="<?php echo e($contract->cost); ?>" class="relative text-[13px] h-[2.813rem] border border-b-color block rounded-md py-1.5 px-3 duration-500 focus:border-primary dark:hover:border-b-color outline-none w-full" placeholder="<?php echo app('translator')->get('locale.cost'); ?>" required>
                                                    </div>
                                                </div>
                                                <div class="lg:w-1/2 mb-2">
                                                    <div class="mb-4">
                                                        <label class="text-body-color dark:text-white"><?php echo app('translator')->get('locale.workforce'); ?> <span class="required text-danger">*</span></label>
                                                        <input type="number" name="contract[workforce]" value="<?php echo e($contract->workforce); ?>" class="relative text-[13px] h-[2.813rem] border border-b-color block rounded-md py-1.5 px-3 duration-500 focus:border-primary dark:hover:border-b-color outline-none w-full" placeholder="<?php echo app('translator')->get('locale.workforce'); ?>" required>
                                                    </div>
                                                </div>
                                                <div class="lg:w-1/2 mb-2">
                                                    <div class="mb-4">
                                                        <label class="text-body-color dark:text-white"><?php echo app('translator')->get('locale.began_at'); ?> <span class="required text-danger">*</span></label>
                                                        <input type="date" name="contract[began_at]" value="<?php echo e($contract->began_at); ?>" class="relative text-[13px] h-[2.813rem] border border-b-color block rounded-md py-1.5 px-3 duration-500 focus:border-primary dark:hover:border-b-color outline-none w-full" id="began_at" required>
                                                    </div>
                                                </div>
                                                <div class="lg:w-1/2 mb-2">
                                                    <div class="mb-4">
                                                        <label class="text-body-color dark:text-white"><?php echo app('translator')->get('locale.ended_at'); ?> <span class="required text-danger">*</span></label>
                                                        <input type="date" name="contract[ended_at]" value="<?php echo e($contract->ended_at); ?>" class="relative text-[13px] h-[2.813rem] border border-b-color block rounded-md py-1.5 px-3 duration-500 focus:border-primary dark:hover:border-b-color outline-none w-full" id="ended_at" required>
                                                    </div>
                                                </div>
                                                <div class="w-full mb-4">
                                                    <div class="mb-4">
                                                        <label class="text-body-color dark:text-white"><?php echo app('translator')->get('locale.description'); ?></label>
                                                        <textarea rows="3" style="resize: none" name="contract[description]" class="form-control relative text-[13px] h-auto min-h-auto border border-b-color block rounded-md p-3 duration-500 focus:border-primary dark:hover:border-b-color outline-none w-full resize-y"><?php echo e($contract->description); ?></textarea>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="accordion-item mb-2">
                                    <div class="accordion-header dark:text-white bg-primary-light text-primary py-[0.7rem] px-3 border border-transparent rounded-md relative cursor-pointer text-sm duration-500 accordion-btn" data-dz-item="collapseTwo">
                                        <span class="accordion-header-icon"></span>
                                        <span class="accordion-header-text"><?php echo app('translator')->get('locale.details'); ?></span>
                                        <span class="accordion-header-indicator"></span>
                                    </div>
                                    <div id="collapseTwo" class="accordion-content hide">
                                        <div class="accordion-body-text py-3.5 px-3 sm:text-sm text-xs text-body-color">
                                            <div class="row">
                                                <div class="flex items-center">
                                                    <a class="rounded py-[5px] px-3 text-[13px] text-success bg-success leading-[18px] inline-block border border-success-light bg-success-light hover:text-white hover:bg-success" id="new-row">+ <?php echo app('translator')->get('locale.new', ['param'=>__('locale.row')]); ?></a>
                                                </div>
                                                <div class="overflow-x-auto table-scroll">
                                                    <table class="table table-bordered table-striped mb-4 min-w-[30rem] w-full">
                                                        <thead>
                                                            <tr>
                                                                <th class="dark:bg-transparent py-[0.9375rem] px-2.5 capitalize whitespace-nowrap font-medium sm:text-base text-sm text-left"><?php echo app('translator')->get('locale.category', ['suffix'=>app()->getLocale() == 'en' ? 'y' : '']); ?></th>
                                                                <th class="dark:bg-transparent py-[0.9375rem] px-2.5 capitalize whitespace-nowrap font-medium sm:text-base text-sm text-left"><?php echo app('translator')->get('locale.label'); ?></th>
                                                                <th class="dark:bg-transparent py-[0.9375rem] px-2.5 capitalize whitespace-nowrap font-medium sm:text-base text-sm text-left"><?php echo app('translator')->get('locale.unit'); ?></th>
                                                                <th class="dark:bg-transparent py-[0.9375rem] px-2.5 capitalize whitespace-nowrap font-medium sm:text-base text-sm text-left"><?php echo app('translator')->get('locale.qty'); ?></th>
                                                                <th class="dark:bg-transparent py-[0.9375rem] px-2.5 capitalize whitespace-nowrap font-medium sm:text-base text-sm text-left"><?php echo app('translator')->get('locale.price'); ?></th>
                                                                <th class="dark:bg-transparent py-[0.9375rem] px-2.5 capitalize whitespace-nowrap font-medium sm:text-base text-sm text-left"><?php echo app('translator')->get('locale.actions'); ?></th>
                                                            </tr>
                                                        </thead>
                                                        <tbody id="tbody">
                                                            <?php $__currentLoopData = $contract->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <tr>
                                                                <td class="py-[0.9375rem] px-2.5 capitalize whitespace-nowrap sm:text-sm text-xs font-normal border-t border-[#E6E6E6] dark:border-[#444444] text-left text-body-color">
                                                                    <input type='text' name="details[<?php echo e($loop->iteration); ?>][category]" value="<?php echo e($detail->category); ?>" placeholder="<?php echo app('translator')->get('locale.category', ['suffix'=>app()->getLocale() == 'en' ? 'y' : '']); ?>" class="form-control form-control-sm" required>
                                                                </td>
                                                                <td class="py-[0.9375rem] px-2.5 capitalize whitespace-nowrap sm:text-sm text-xs font-normal border-t border-[#E6E6E6] dark:border-[#444444] text-left text-body-color">
                                                                    <input type='text' name="details[<?php echo e($loop->iteration); ?>][label]" value="<?php echo e($detail->label); ?>" class="form-control form-control-sm" placeholder="<?php echo app('translator')->get('locale.label'); ?>" required>
                                                                </td>
                                                                <td class="py-[0.9375rem] px-2.5 capitalize whitespace-nowrap sm:text-sm text-xs font-normal border-t border-[#E6E6E6] dark:border-[#444444] text-left text-body-color">
                                                                    <input type='text' name="details[<?php echo e($loop->iteration); ?>][unit]" value="<?php echo e($detail->unit); ?>" class="form-control form-control-sm" placeholder="<?php echo app('translator')->get('locale.unit'); ?>" required>
                                                                </td>
                                                                <td class="py-[0.9375rem] px-2.5 capitalize whitespace-nowrap sm:text-sm text-xs font-normal border-t border-[#E6E6E6] dark:border-[#444444] text-left text-body-color">
                                                                    <input type='number' name="details[<?php echo e($loop->iteration); ?>][qty]" value="<?php echo e($detail->qty); ?>" step="0.01" min="1" class="form-control form-control-sm" placeholder="<?php echo app('translator')->get('locale.qty'); ?>" required>
                                                                </td>
                                                                <td class="py-[0.9375rem] px-2.5 capitalize whitespace-nowrap sm:text-sm text-xs font-normal border-t border-[#E6E6E6] dark:border-[#444444] text-left">
                                                                    <input type='number' name="details[<?php echo e($loop->iteration); ?>][price]" value="<?php echo e($detail->price); ?>" min="500" class="form-control form-control-sm" placeholder="<?php echo app('translator')->get('locale.price'); ?>" required>
                                                                </td>
                                                                <td class="py-[0.9375rem] px-2.5 capitalize whitespace-nowrap sm:text-sm text-xs font-normal border-t border-[#E6E6E6] dark:border-[#444444] text-left text-body-color">
                                                                    <i class="fa fa-trash text-danger" onclick="deleter(this)"></i>
                                                                </td>
                                                            </tr>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </tbody>
                                                    </table>
                                                </div>	
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="w-full">
                                    <button class="block w-full btn btn-success xl:py-[0.719rem] py-2.5 xl:px-[1.563rem] px-4 duration-300 xl:text-[15px] text-[13px] font-medium rounded text-white bg-primary leading-5 inline-block border border-primary hover:bg-hover-primary offcanvas-close"><?php echo app('translator')->get('locale.submit'); ?></button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php $__env->startPush('scripts'); ?>
	<script src="<?php echo e(asset('vendor/niceselect/js/jquery.nice-select.min.js')); ?>"></script> 
    <script src="<?php echo e(asset('vendor/select2/js/select2.full.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/plugins-init/select2-init.js')); ?>"></script>
    <script src="<?php echo e(asset('js/details.js')); ?>"></script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>

<?php /**PATH C:\laragon\www\gmpsarl.com\resources\views/admin/contracts/edit.blade.php ENDPATH**/ ?>