<nav class="navbar navbar-expand-xl sticky-top bg-white  w-100 border-bottom">
    <div class="container">
        <div class="d-flex justify-content-between w-100 align-items-center">
            <div class="d-flex align-items-center w-100 w-md-auto">
                <button class="navbar-toggler offcanvas-nav-btn" type="button">
                    <i class="bi bi-list"></i>
                </button>
                <a class="navbar-brand mx-auto mx-xxl-0 ms-4" href="<?php echo e(route('welcome')); ?>">
                    <img src="<?php echo e(asset('images/logo.png')); ?>" height="60" width="70" alt="LOGO" />
                </a>
            </div>
            <div class="">
                <div class="offcanvas offcanvas-bottom offcanvas-nav" style="height: 60vh">
                    <div class="offcanvas-header position-absolute top-0 start-50 translate-middle mt-n5">
                        <button type="button" class="btn-close bg-white opacity-100" data-bs-dismiss="offcanvas" aria-label="Close"></button>
                    </div>
                    <div class="offcanvas-body pt-xl-0 align-items-center">
                        <ul class="navbar-nav mb-2 mb-lg-0 ">
                            <li class="nav-item border-bottom border-bottom-xl-0">
                                <a class="nav-link" href="tel:+224610421717"><i class="bi bi-bank ms-2"></i> MAFAMO BOOKING | <i class="bi bi-telephone-inbound-fill ms-2"></i> +224610421717</a>
                            </li>
                        </ul>
                        <div class="d-xl-none d-grid position-absolute bottom-0 w-100 start-0 end-0 p-4">
                            <a href="signin.html" class="btn btn-primary">Sign in</a>
                        </div>
                    </div>
                </div>
            </div>

            <div class="d-flex align-items-center gap-4">
                <div class="dropdown d-none d-md-block">
                    <a class="d-flex align-items-center gap-1" href="product-no-filter.html#!" id="currencyDropdown"
                        data-bs-toggle="dropdown" aria-expanded="false">
                        <img id="current-flag" src="https://img.icons8.com/color/48/guinea.png" alt="GBP" height="16" width="16" />
                        <span id="current-currency"><?php echo e(session('currency')); ?></span>
                        <i id="arrowIcon" class="bi bi-chevron-down ms-2"></i>
                    </a>
                    <ul class="dropdown-menu bg-white shadow" aria-labelledby="currencyDropdown">
                        <?php $__currentLoopData = ['GNF', 'EURO', 'USD']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $currency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($currency != session('currency')): ?>
                            <li>
                                <a class="dropdown-item d-flex align-items-center" href="<?php echo e(route('currencies.change', $currency)); ?>">
                                    <img class="flag-icon" width="16" height="16" src="https://img.icons8.com/color/48/flag-of-europe.png" alt="<?php echo e($currency); ?>"/>
                                    <?php echo e($currency); ?>

                                </a>
                            </li>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <div class="d-flex align-items-center gap-3">
                    
                </div>
            </div>
        </div>
    </div>
</nav><?php /**PATH C:\laragon\www\gmpsarl.com\resources\views/components/nav.blade.php ENDPATH**/ ?>