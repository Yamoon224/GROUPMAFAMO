<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <!-- [ page-header ] start -->
    <div class="page-header">
        <div class="page-header-left d-flex align-items-center">
            <div class="page-header-title">
                <h5 class="m-b-10"><?php echo app('translator')->get('locale.partner', ['suffix'=>'s']); ?></h5>
            </div>
            <ul class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>"><?php echo app('translator')->get('locale.dashboard'); ?></a></li>
                <li class="breadcrumb-item"><?php echo app('translator')->get('locale.partner', ['suffix'=>'s']); ?></li>
            </ul>
        </div>
        <div class="page-header-right ms-auto">
            <div class="page-header-right-items">
                <div class="d-flex d-md-none">
                    <a href="javascript:void(0)" class="page-header-right-close-toggle">
                        <i class="feather-arrow-left me-2"></i>
                        <span>Back</span>
                    </a>
                </div>
                <div class="d-flex align-items-center gap-2 page-header-right-items-wrapper">
                    <div class="dropdown filter-dropdown">
                        <a class="btn btn-md btn-light-brand" data-bs-toggle="dropdown" data-bs-offset="0, 10" data-bs-auto-close="outside">
                            <i class="feather-filter me-2"></i>
                            <span>Filter</span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end">
                            <div class="dropdown-item">
                                <div class="custom-control custom-checkbox">
                                    <input type="checkbox" class="custom-control-input" id="Role" checked="checked">
                                    <label class="custom-control-label c-pointer" for="Role">Role</label>
                                </div>
                            </div>
                            <div class="dropdown-item">
                                <div class="custom-control custom-checkbox">
                                    <input type="checkbox" class="custom-control-input" id="Team" checked="checked">
                                    <label class="custom-control-label c-pointer" for="Team">Team</label>
                                </div>
                            </div>
                            <div class="dropdown-item">
                                <div class="custom-control custom-checkbox">
                                    <input type="checkbox" class="custom-control-input" id="Email" checked="checked">
                                    <label class="custom-control-label c-pointer" for="Email">Email</label>
                                </div>
                            </div>
                            <div class="dropdown-item">
                                <div class="custom-control custom-checkbox">
                                    <input type="checkbox" class="custom-control-input" id="Member" checked="checked">
                                    <label class="custom-control-label c-pointer" for="Member">Member</label>
                                </div>
                            </div>
                            <div class="dropdown-item">
                                <div class="custom-control custom-checkbox">
                                    <input type="checkbox" class="custom-control-input" id="Recommendation" checked="checked">
                                    <label class="custom-control-label c-pointer" for="Recommendation">Recommendation</label>
                                </div>
                            </div>
                            <div class="dropdown-divider"></div>
                            <a href="javascript:void(0);" class="dropdown-item">
                                <i class="feather-plus me-3"></i>
                                <span>Create New</span>
                            </a>
                            <a href="javascript:void(0);" class="dropdown-item">
                                <i class="feather-filter me-3"></i>
                                <span>Manage Filter</span>
                            </a>
                        </div>
                    </div>
                    <a href="javascript:void(0);" class="btn btn-md btn-primary">
                        <i class="feather-plus me-2"></i>
                        <span><?php echo app('translator')->get('locale.add'); ?></span>
                    </a>
                </div>
            </div>
            <div class="d-md-none d-flex align-items-center">
                <a href="javascript:void(0)" class="page-header-right-open-toggle">
                    <i class="feather-align-right fs-20"></i>
                </a>
            </div>
        </div>
    </div>
    <!-- [ page-header ] end -->
    <!-- [ Main Content ] start -->
    <div class="main-content">
        <div class="row">
            <div class="col-lg-12">
                <div class="card stretch stretch-full">
                    <div class="card-header">
                        <h5 class="card-title"><?php echo app('translator')->get('locale.partner', ['suffix'=>'s']); ?></h5>
                        <div class="card-header-action">
                            <div class="card-header-btn">
                                <div data-bs-toggle="tooltip" title="Refresh">
                                    <a href="javascript:void(0);" class="avatar-text avatar-xs bg-warning" data-bs-toggle="refresh"> </a>
                                </div>
                                <div data-bs-toggle="tooltip" title="Maximize/Minimize">
                                    <a href="javascript:void(0);" class="avatar-text avatar-xs bg-success" data-bs-toggle="expand"></a>
                                </div>
                            </div>
                            <div class="dropdown">
                                <a href="javascript:void(0);" class="avatar-text avatar-sm" data-bs-toggle="dropdown" data-bs-offset="25, 25">
                                    <div data-bs-toggle="tooltip" title="Options">
                                        <i class="feather-more-vertical"></i>
                                    </div>
                                </a>
                                <div class="dropdown-menu dropdown-menu-end">
                                    <a href="javascript:void(0);" class="dropdown-item"><i class="feather-at-sign"></i>New</a>
                                    <a href="javascript:void(0);" class="dropdown-item"><i class="feather-calendar"></i>Event</a>
                                    <a href="javascript:void(0);" class="dropdown-item"><i class="feather-bell"></i>Snoozed</a>
                                    <a href="javascript:void(0);" class="dropdown-item"><i class="feather-trash-2"></i>Deleted</a>
                                    <div class="dropdown-divider"></div>
                                    <a href="javascript:void(0);" class="dropdown-item"><i class="feather-settings"></i>Settings</a>
                                    <a href="javascript:void(0);" class="dropdown-item"><i class="feather-life-buoy"></i>Tips & Tricks</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-body custom-card-action p-0">
                        <div class="table-responsive">
                            <table class="table table-hover mb-0">
                                <thead>
                                    <tr>
                                        <th scope="col"><?php echo app('translator')->get('locale.partner', ['suffix'=>'']); ?></th>
                                        <th scope="col" class="w-25"><?php echo app('translator')->get('locale.owner'); ?></th>
                                        <th scope="col"><?php echo app('translator')->get('locale.company'); ?></th>
                                        <th scope="col"><?php echo app('translator')->get('locale.created_at'); ?></th>
                                        <th scope="col" class="text-end"><?php echo app('translator')->get('locale.actions'); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $partners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <div class="hstack gap-3">
                                                <div class="avatar-image avatar-lg rounded">
                                                    <img class="img-fluid" src="<?php echo e(asset( $item->logo ?? 'images/profile.png' )); ?>" alt="">
                                                </div>
                                                <div>
                                                    <a href="<?php echo e(route('partners.show', $item->id)); ?>" class="d-block mb-1"><?php echo e($item->name); ?></a>
                                                    <div class="d-flex gap-3">
                                                        <a href="javascript:void(0);" class="hstack gap-1 fs-11 fw-normal text-muted">
                                                            <i class="feather-clock fs-10"></i> <span><?php echo e($item->contracts->count()); ?> <?php echo app('translator')->get('locale.contract', ['suffix'=>'']); ?></span>
                                                        </a>
                                                        <a href="javascript:void(0);" class="hstack gap-1 fs-11 fw-normal text-muted">
                                                            <i class="feather-message-square fs-10"></i>
                                                            <span>32 comments</span>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <a class="d-block mb-1"><?php echo e($item->owner); ?></a>
                                            <span class="fs-12 text-muted d-block"><?php echo e($item->phone); ?></span>
                                        </td>
                                        <td>
                                            <a class="d-block mb-1"><span class="badge text-success border border-success border-dashed"><?php echo e($item->type); ?></span></a>
                                            <span class="fs-12 text-muted d-block"><?php echo e($item->email); ?></span>
                                        </td>
                                        <td>
                                            <a class="d-block mb-1"><?php echo e(date('d/m/Y', strtotime($item->created_at))); ?></a>
                                            <span class="fs-12 text-muted d-block"><?php echo e(date('H:i:s', strtotime($item->created_at))); ?></span>
                                        </td>
                                        <td>
                                            <div class="hstack gap-2 justify-content-end">
                                                <a href="<?php echo e(route('partners.show', $item->id)); ?>" class="avatar-text avatar-md" title="<?php echo app('translator')->get('locale.show', ['param'=>__('locale.partner', ['suffix'=>''])]); ?>">
                                                    <i class="feather-eye"></i>
                                                </a>
                                                <a href="<?php echo e(route('partners.edit', $item->id)); ?>" class="avatar-text avatar-md" title="<?php echo app('translator')->get('locale.edit', ['param'=>__('locale.partner', ['suffix'=>''])]); ?>">
                                                    <i class="feather-edit"></i>
                                                </a>
                                                <form action="<?php echo e(route('partners.destroy', $item->id)); ?>" method="post">
                                                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                                    <button class="avatar-text avatar-md">
                                                        <i class="feather-trash-2"></i>
                                                    </button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="card-footer">
                        <ul class="list-unstyled d-flex align-items-center gap-2 mb-0 pagination-common-style">
                            <li>
                                <a href="javascript:void(0);"><i class="bi bi-arrow-left"></i></a>
                            </li>
                            <li><a href="javascript:void(0);" class="active">1</a></li>
                            <li><a href="javascript:void(0);">2</a></li>
                            <li>
                                <a href="javascript:void(0);"><i class="bi bi-dot"></i></a>
                            </li>
                            <li><a href="javascript:void(0);">8</a></li>
                            <li><a href="javascript:void(0);">9</a></li>
                            <li>
                                <a href="javascript:void(0);"><i class="bi bi-arrow-right"></i></a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- [ Main Content ] end -->
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>

<?php /**PATH C:\laragon\www\gmpsarl.com\resources\views/admin/partners.blade.php ENDPATH**/ ?>