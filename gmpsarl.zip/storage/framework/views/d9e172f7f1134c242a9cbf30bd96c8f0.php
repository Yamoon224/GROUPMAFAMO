<div class="nav-header">
    <a href="<?php echo e(route('dashboard')); ?>" class="brand-logo">
        <img src="<?php echo e(asset('images/logo.png')); ?>" class="logo-abbr" alt="LOGO" style="height: 60px; width: 80px">
    </a>
    <div class="nav-control">
        <div class="hamburger">
            <span class="line"></span>
            <span class="line"></span>
            <span class="line"></span>
        </div>
    </div>
</div><?php /**PATH C:\laragon\www\gmpsarl.com\resources\views/components/app-navheader.blade.php ENDPATH**/ ?>