<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <form action="<?php echo e(route('categories.update', $category->id)); ?>" method="post">
        <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
        <!-- [ page-header ] start -->
        <div class="page-header">
            <div class="page-header-left d-flex align-items-center">
                <div class="page-header-title">
                    <h5 class="m-b-10"><?php echo app('translator')->get('locale.category', ['suffix'=>app()->getLocale() == 'en' ? 'y' : '']); ?></h5>
                </div>
                <ul class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('categories.index')); ?>"><?php echo app('translator')->get('locale.category', ['suffix'=>app()->getLocale() == 'en' ? 'ies' : 's']); ?></a></li>
                    <li class="breadcrumb-item"><?php echo app('translator')->get('locale.new', ['param'=>'']); ?></li>
                </ul>
            </div>
            <div class="page-header-right ms-auto">
                <div class="page-header-right-items">
                    <div class="d-flex d-md-none">
                        <a href="javascript:void(0)" class="page-header-right-close-toggle">
                            <i class="feather-arrow-left me-2"></i>
                            <span>Back</span>
                        </a>
                    </div>
                    <div class="d-flex align-items-center gap-2 page-header-right-items-wrapper">
                        <button class="btn btn-md btn-success" title="<?php echo app('translator')->get('locale.submit'); ?>">
                            <i class="feather-user-plus me-2"></i> <span><?php echo app('translator')->get('locale.submit'); ?></span>
                        </button>
                    </div>
                </div>
                <div class="d-md-none d-flex align-items-center">
                    <a href="javascript:void(0)" class="page-header-right-open-toggle">
                        <i class="feather-align-right fs-20"></i>
                    </a>
                </div>
            </div>
        </div>
        <!-- [ page-header ] end -->
        <!-- [ Main Content ] start -->
        <div class="main-content">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card border-top-0">
                        <div class="card-header p-0">
                        </div>
                        <div class="card-body personal-info">
                            <div class="mb-4 d-flex align-items-center justify-content-between">
                                <h5 class="fw-bold mb-0 me-2">
                                    <span class="d-block mb-2"><?php echo app('translator')->get('locale.category', ['suffix'=>app()->getLocale() == 'en' ? 'y' : '']); ?></span>
                                    <span class="fs-12 fw-normal text-muted text-truncate-1-line"><span class="text-danger">*</span> <?php echo app('translator')->get('locale.required_fields'); ?></span>
                                </h5>
                            </div>
                            <div class="row">
                                <div class="col-12 text-center">
                                    <p class="fs-12 fw-medium text-muted text-danger"><?php echo e(!empty($errors) && !empty($errors->all()) ? implode('', $errors->all()) : (session('status') ? session('status') : "")); ?></p>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-12 py-2">
                                    <label for="company" class="fw-semibold"><?php echo app('translator')->get('locale.category', ['suffix'=>app()->getLocale() == 'en' ? 'y' : '']); ?> <span class='text-danger'>*</span></label>
                                    <div class="input-group">
                                        <div class="input-group-text"><i class="feather-compass"></i></div>
                                        <input type="text" class="form-control" id="category" value="<?php echo e($category->category); ?>" placeholder="<?php echo app('translator')->get('locale.category', ['suffix'=>app()->getLocale() == 'en' ? 'y' : '']); ?>" name="category" required>
                                    </div>
                                </div>
                                <div class="col-12 py-2">
                                    <label for="description" class="fw-semibold"><?php echo app('translator')->get('locale.description'); ?> </label>
                                    <div class="input-group">
                                        <div class="input-group-text"><i class="feather-type"></i></div>
                                        <textarea class="form-control" id="description" name="description" cols="30" rows="5" placeholder="<?php echo app('translator')->get('locale.description'); ?>" style="resize: none"><?php echo e($category->description); ?></textarea>
                                    </div>
                                </div>                         
                            </div>                       
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- [ Main Content ] end -->
    </form>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\gmpsarl.com\resources\views/admin/categories/edit.blade.php ENDPATH**/ ?>