<div class="footer dark:bg-[#242424] mt-4 border-t border-[#E6E6E6] dark:border-[#444444] text-[13px] font-normal">
    <div class="copyright p-[0.9375rem]">
       <p class="text-center text-[#918f8f] dark:text-[#ffffffb3] sm:text-sm text-xs leading-[1.8]">Copyright © Developed by <a href="https://editosystem.com" target="_blank" class="text-primary">{{ env('APP_CONCEPTOR') }}</a> {{ date('Y') }}</p>
    </div>
</div>