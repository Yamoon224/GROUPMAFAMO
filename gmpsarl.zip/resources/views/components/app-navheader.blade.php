<div class="nav-header">
    <a href="{{ route('dashboard') }}" class="brand-logo">
        <img src="{{ asset('images/logo.png') }}" class="logo-abbr" alt="LOGO" style="height: 60px; width: 80px">
    </a>
    <div class="nav-control">
        <div class="hamburger">
            <span class="line"></span>
            <span class="line"></span>
            <span class="line"></span>
        </div>
    </div>
</div>