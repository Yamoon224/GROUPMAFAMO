<img src="{{ asset('images/logo.png') }}" class="img-circle" alt="" height="{{ $height ?? 100 }}" width="{{ $width ?? 100 }}">
