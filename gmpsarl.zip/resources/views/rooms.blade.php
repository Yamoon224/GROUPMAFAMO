@foreach ($rooms as $item)
<x-room :room="$item"></x-room>
@endforeach